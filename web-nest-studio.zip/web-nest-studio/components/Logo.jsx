"use client";

import { useId } from "react";

/**
 * Web Nest Studio identity.
 * Symbol: three nested "W" strokes (layers of a nest / stacked web layers) cradling a single node
 * (the idea, the signal, the egg). Monochrome silver so it holds on any dark surface.
 *
 * Variants
 *  - mark     symbol only (favicon, chat avatar, tight spaces)
 *  - compact  symbol + "WEB NEST" (mobile navigation)
 *  - full     symbol + "WEB NEST / STUDIO" (desktop navigation, footer)
 *  - stacked  symbol above wordmark (intro, loading screens)
 */

export function LogoMark({ size = 40, animate = false, className = "", title }) {
  const uid = useId().replace(/:/g, "");
  const g = `wns-g-${uid}`;
  const g2 = `wns-g2-${uid}`;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      role={title ? "img" : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      className={className}
      data-logo-mark
    >
      <defs>
        <linearGradient id={g} x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset=".45" stopColor="#bfc3cc" />
          <stop offset=".75" stopColor="#f4f5f7" />
          <stop offset="1" stopColor="#7d818c" />
        </linearGradient>
        <linearGradient id={g2} x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffffff" stopOpacity=".9" />
          <stop offset="1" stopColor="#9fa4b0" stopOpacity=".55" />
        </linearGradient>
      </defs>
      <g strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.2">
        <path
          d="M5 10 L19 54 L32 24 L45 54 L59 10"
          stroke={`url(#${g})`}
          pathLength="1"
          data-draw={animate ? "" : undefined}
        />
        <path
          d="M14 20 L24 50 L32 34 L40 50 L50 20"
          stroke={`url(#${g2})`}
          strokeWidth="2.6"
          pathLength="1"
          data-draw={animate ? "" : undefined}
        />
        <path
          d="M23 29 L28 46 L32 40 L36 46 L41 29"
          stroke={`url(#${g2})`}
          strokeWidth="2"
          pathLength="1"
          opacity=".8"
          data-draw={animate ? "" : undefined}
        />
      </g>
      <circle cx="32" cy="12" r="2.8" fill={`url(#${g})`} data-node />
    </svg>
  );
}

export default function Logo({ variant = "full", size, className = "", animate = false }) {
  if (variant === "mark") {
    return <LogoMark size={size || 40} animate={animate} className={className} title="Web Nest Studio" />;
  }

  if (variant === "stacked") {
    return (
      <div className={`flex flex-col items-center ${className}`} data-logo-stacked>
        <LogoMark size={size || 96} animate={animate} />
        <div className="mt-6 text-center">
          <p className="logo-word font-display text-3xl font-bold tracking-[0.42em] text-white sm:text-4xl">
            <span className="sr-only">Web Nest Studio</span>
            <span aria-hidden="true">WEB NEST</span>
          </p>
          <p className="logo-sub mt-2 font-mono text-[11px] tracking-[0.7em] text-mist sm:text-xs" aria-hidden="true">
            STUDIO
          </p>
        </div>
      </div>
    );
  }

  const compact = variant === "compact";
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <LogoMark size={size || (compact ? 30 : 36)} animate={animate} />
      <span className="flex flex-col leading-none">
        <span className="font-display text-[15px] font-bold tracking-[0.3em] text-white">
          <span className="sr-only">Web Nest Studio</span>
          <span aria-hidden="true">WEB NEST</span>
        </span>
        {!compact && (
          <span className="mt-1 font-mono text-[8px] tracking-[0.62em] text-mist" aria-hidden="true">
            STUDIO
          </span>
        )}
      </span>
    </span>
  );
}
