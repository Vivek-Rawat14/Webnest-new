import { Reveal, SplitReveal } from "./Reveal";

export default function SectionHead({ eyebrow, title, text, as = "h2", className = "" }) {
  return (
    <div className={`mb-12 max-w-3xl sm:mb-16 ${className}`}>
      {eyebrow && (
        <Reveal y={16}>
          <p className="eyebrow mb-5 flex items-center gap-3">
            <span className="h-px w-8 bg-white/30" aria-hidden="true" />
            {eyebrow}
          </p>
        </Reveal>
      )}
      <SplitReveal as={as} text={title} className="h-display text-[clamp(2rem,5.4vw,4rem)] text-white" />
      {text && (
        <Reveal delay={0.15} className="mt-6 max-w-2xl text-base leading-relaxed text-mist sm:text-lg">
          <p>{text}</p>
        </Reveal>
      )}
    </div>
  );
}
