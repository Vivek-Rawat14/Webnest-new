"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Bot, ArrowUp, X, Sparkles } from "lucide-react";
import ErrorBoundary from "./ErrorBoundary";
import { greetingFor, localAnswer } from "@/lib/knowledge";
import { site } from "@/lib/site";

const RobotScene = dynamic(() => import("./RobotScene"), {
  ssr: false,
  loading: () => <Bot size={26} className="text-white/60" aria-hidden="true" />,
});

const SUGGESTIONS = [
  "What services do you provide?",
  "Show me your Shopify projects",
  "Tell me about your case studies",
  "How can I contact you?",
];

function hasWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

function Robot({ talking, webgl }) {
  const fallback = <Bot size={26} className="text-white" aria-hidden="true" />;
  if (!webgl) return <div className="grid h-full w-full place-items-center">{fallback}</div>;
  return (
    <ErrorBoundary fallback={<div className="grid h-full w-full place-items-center">{fallback}</div>}>
      <RobotScene talking={talking} />
    </ErrorBoundary>
  );
}

function Links({ links, onNavigate }) {
  if (!links?.length) return null;
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {links.map((l) =>
        l.href.startsWith("/") ? (
          <Link
            key={l.href + l.label}
            href={l.href}
            onClick={onNavigate}
            className="inline-flex min-h-[36px] items-center rounded-full border border-white/20 bg-white/[0.06] px-3.5 text-xs text-white transition hover:bg-white/15"
          >
            {l.label}
          </Link>
        ) : (
          <a
            key={l.href + l.label}
            href={l.href}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[36px] items-center rounded-full border border-white/20 bg-white/[0.06] px-3.5 text-xs text-white transition hover:bg-white/15"
          >
            {l.label} &#8599;
          </a>
        )
      )}
    </div>
  );
}

/** Reveals text character by character; instant for reduced motion. */
function Typed({ text, animate, onTick, onDone, children }) {
  const [n, setN] = useState(animate ? 0 : text.length);
  const doneRef = useRef(!animate);
  useEffect(() => {
    if (!animate) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setN(text.length);
      return;
    }
    const step = Math.max(1, Math.round(text.length / 140));
    const id = setInterval(() => {
      setN((c) => {
        const next = Math.min(c + step, text.length);
        if (next >= text.length) clearInterval(id);
        return next;
      });
    }, 18);
    return () => clearInterval(id);
  }, [animate, text]);
  useEffect(() => {
    onTick?.();
    if (n >= text.length && !doneRef.current) {
      doneRef.current = true;
      onDone?.();
    }
  }, [n, text, onTick, onDone]);
  const finished = n >= text.length;
  return (
    <>
      <span>{text.slice(0, n)}</span>
      {!finished && <span className="ml-0.5 inline-block h-3.5 w-[2px] translate-y-0.5 animate-pulse bg-white/70" aria-hidden="true" />}
      {finished && children}
    </>
  );
}

export default function ChatAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [talking, setTalking] = useState(false);
  const [webgl, setWebgl] = useState(false);
  const [teaser, setTeaser] = useState(false);
  const [mode, setMode] = useState(null);
  const logRef = useRef(null);
  const inputRef = useRef(null);
  const buttonRef = useRef(null);
  const idRef = useRef(0);
  const seeded = useRef(false);

  useEffect(() => {
    setWebgl(hasWebGL());
    const t = setTimeout(() => setTeaser(true), 6000);
    const h = setTimeout(() => setTeaser(false), 16000);
    return () => {
      clearTimeout(t);
      clearTimeout(h);
    };
  }, []);

  const scroll = useCallback(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, []);

  const push = useCallback((m) => {
    const id = ++idRef.current;
    setMessages((cur) => [...cur, { id, animate: m.role === "assistant", ...m }]);
    return id;
  }, []);

  // First open: time-aware greeting + self-introduction.
  useEffect(() => {
    if (!open || seeded.current) return;
    seeded.current = true;
    push({ role: "assistant", text: greetingFor(new Date()), greeting: true });
    setTimeout(
      () =>
        push({
          role: "assistant",
          text: `I'm the AI portfolio assistant of ${site.name}. Ask me about services, projects, technologies or how to get in touch.`,
          chips: true,
        }),
      900
    );
  }, [open, push]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 350);
  }, [open]);

  useEffect(() => {
    scroll();
  }, [messages, busy, scroll]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const send = useCallback(
    async (raw) => {
      const text = raw.trim().slice(0, 500);
      if (!text || busy) return;
      setInput("");
      push({ role: "user", text });
      setBusy(true);
      const history = [...messages, { role: "user", text }]
        .filter((m) => !m.greeting)
        .slice(-10)
        .map((m) => ({ role: m.role, content: m.text }));
      let reply;
      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: history }),
        });
        const data = await res.json();
        if (!data.reply) throw new Error("empty");
        reply = data;
      } catch {
        // Network or server failure: the bundled knowledge base still answers.
        reply = { ...localAnswer(text), mode: "local" };
      }
      setMode(reply.mode || "local");
      setBusy(false);
      setTalking(true);
      push({ role: "assistant", text: reply.reply, links: reply.links });
    },
    [busy, messages, push]
  );

  const closeOnMobile = () => {
    if (window.innerWidth < 640) setOpen(false);
  };

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.section
            role="dialog"
            aria-label="Web Nest Studio AI assistant"
            initial={{ opacity: 0, y: 30, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            style={{ transformOrigin: "bottom right" }}
            className="fixed bottom-[88px] right-3 z-50 flex h-[min(620px,calc(100dvh-7.5rem))] w-[min(400px,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-3xl border border-white/15 bg-[#0a0a0e]/95 shadow-[0_30px_80px_-20px_rgba(0,0,0,.9)] backdrop-blur-xl sm:bottom-[100px] sm:right-6"
          >
            <header className="relative flex items-center gap-3 border-b border-white/10 px-4 py-3">
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-2xl bg-gradient-to-b from-white/10 to-transparent">
                <Robot talking={talking || busy} webgl={webgl} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-display text-base font-bold leading-tight text-white">Nest Assistant</p>
                <p className="flex items-center gap-1.5 text-xs text-mist">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
                  {mode === "ai" ? "AI-powered" : "Portfolio knowledge base"}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  buttonRef.current?.focus();
                }}
                aria-label="Close assistant"
                className="grid h-11 w-11 place-items-center rounded-full text-mist transition hover:bg-white/10 hover:text-white"
              >
                <X size={18} />
              </button>
            </header>

            <div ref={logRef} className="flex-1 space-y-3 overflow-y-auto overscroll-contain px-4 py-4" role="log" aria-live="polite" aria-label="Conversation">
              {messages.map((m) => (
                <motion.div
                  key={m.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35 }}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[86%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      m.role === "user"
                        ? "rounded-br-md bg-white text-ink"
                        : "rounded-bl-md border border-white/10 bg-white/[0.06] text-silver"
                    }`}
                  >
                    {m.role === "user" ? (
                      m.text
                    ) : (
                      <Typed text={m.text} animate={m.animate} onTick={scroll} onDone={() => setTalking(false)}>
                        <Links links={m.links} onNavigate={closeOnMobile} />
                        {m.chips && (
                          <div className="mt-3 flex flex-col gap-2">
                            {SUGGESTIONS.map((s) => (
                              <button
                                key={s}
                                type="button"
                                onClick={() => send(s)}
                                className="min-h-[40px] rounded-xl border border-white/15 bg-white/[0.04] px-3 py-2 text-left text-xs text-white transition hover:bg-white/12"
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        )}
                      </Typed>
                    )}
                  </div>
                </motion.div>
              ))}
              {busy && (
                <div className="flex justify-start" aria-label="Assistant is typing">
                  <div className="flex gap-1.5 rounded-2xl rounded-bl-md border border-white/10 bg-white/[0.06] px-4 py-3.5">
                    {[0, 1, 2].map((i) => (
                      <span key={i} className="h-1.5 w-1.5 animate-bounce rounded-full bg-silver" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex items-center gap-2 border-t border-white/10 p-3"
            >
              <label htmlFor="chat-input" className="sr-only">
                Ask a question
              </label>
              <input
                id="chat-input"
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                maxLength={500}
                autoComplete="off"
                placeholder="Ask about services, projects..."
                className="min-h-[46px] flex-1 rounded-full border border-white/12 bg-white/[0.05] px-4 text-base text-white placeholder:text-mist/70 focus:border-white/40"
              />
              <button
                type="submit"
                disabled={!input.trim() || busy}
                aria-label="Send message"
                className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white text-ink transition disabled:opacity-40"
              >
                <ArrowUp size={18} />
              </button>
            </form>
          </motion.section>
        )}
      </AnimatePresence>

      <div className="fixed bottom-4 right-3 z-50 sm:bottom-6 sm:right-6">
        <AnimatePresence>
          {teaser && !open && (
            <motion.div
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              className="glass absolute bottom-3 right-[84px] hidden whitespace-nowrap rounded-full px-4 py-2 text-xs text-white sm:flex sm:items-center sm:gap-2"
            >
              <Sparkles size={13} aria-hidden="true" /> Ask me anything
            </motion.div>
          )}
        </AnimatePresence>
        <button
          ref={buttonRef}
          type="button"
          onClick={() => {
            setOpen((v) => !v);
            setTeaser(false);
          }}
          aria-label={open ? "Close AI assistant" : "Open AI assistant"}
          aria-expanded={open}
          data-cursor={open ? "Close" : "Ask"}
          className="group relative grid h-[76px] w-[76px] place-items-center rounded-full border border-white/20 bg-gradient-to-b from-[#1a1a22] to-[#0a0a0e] shadow-[0_14px_40px_-8px_rgba(124,92,255,.55)] transition hover:scale-105"
        >
          <span className="pointer-events-none absolute inset-0 rounded-full border border-volt/50" style={{ animation: "ring 2.6s ease-out infinite" }} aria-hidden="true" />
          <div className="absolute inset-0 overflow-hidden rounded-full">
            {open ? (
              <div className="grid h-full w-full place-items-center text-white">
                <X size={24} aria-hidden="true" />
              </div>
            ) : (
              <Robot talking={false} webgl={webgl} />
            )}
          </div>
        </button>
      </div>
    </>
  );
}
