"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import dynamic from "next/dynamic";
import Link from "next/link";
import { ArrowUpRight, Boxes, Layers, LayoutTemplate, PenTool, RefreshCw, ShoppingBag, Smartphone, Wrench } from "lucide-react";
import { Reveal } from "./Reveal";
import TiltCard from "./TiltCard";
import ErrorBoundary from "./ErrorBoundary";
import { services } from "@/lib/data";
import { canUse3D } from "@/lib/webgl";

const icons = { ShoppingBag, Layers, Boxes, LayoutTemplate, Smartphone, PenTool, RefreshCw, Wrench };
// The 3D shapes (and View.Port) load only when this section is near the viewport.
const ServiceView = dynamic(() => import("./ServiceShapes").then((m) => m.ServiceView), { ssr: false });
const ServiceCanvas = dynamic(() => import("./ServiceShapes").then((m) => m.ServiceCanvas), { ssr: false });

export default function Services() {
  const grid = useRef(null);
  const [on, setOn] = useState(false); // WebGL available and section seen
  const [failed, setFailed] = useState(false);
  const [active, setActive] = useState(false);
  const [capable, setCapable] = useState(false);

  useEffect(() => setCapable(canUse3D()), []);

  useEffect(() => {
    const el = grid.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        setActive(e.isIntersecting);
        if (e.isIntersecting) setOn(true);
      },
      { rootMargin: "300px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const use3d = capable && on && !failed;

  return (
    <div ref={grid}>
      <Reveal stagger={0.08} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" y={36}>
        {services.map((s, i) => {
          const Icon = icons[s.icon];
          return (
            <TiltCard key={s.id} className="group panel flex min-h-[340px] flex-col rounded-3xl p-6 hover:border-white/25">
              <div className="flex items-start justify-between">
                <span className="font-mono text-xs text-mist">{s.number}</span>
              </div>
              <div className="relative -mx-2 mt-1 h-36" aria-hidden="true">
                {use3d ? (
                  <ErrorBoundary onError={() => setFailed(true)} fallback={null}>
                    <ServiceView index={i} className="absolute inset-0" />
                  </ErrorBoundary>
                ) : (
                  <span className="absolute inset-0 grid place-items-center">
                    <span className="grid h-16 w-16 place-items-center rounded-2xl border border-white/15 bg-gradient-to-br from-white/15 to-white/[0.03] text-white">
                      <Icon size={26} strokeWidth={1.5} />
                    </span>
                  </span>
                )}
              </div>
              <h3 className="h-display mt-4 text-[1.35rem] leading-tight text-white">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-mist">{s.desc}</p>
              <Link
                href={`/contact?service=${s.id}`}
                className="mt-auto inline-flex min-h-[44px] items-center gap-1.5 pt-5 text-sm text-white transition-all duration-500 sm:translate-y-3 sm:opacity-0 sm:group-focus-within:translate-y-0 sm:group-focus-within:opacity-100 sm:group-hover:translate-y-0 sm:group-hover:opacity-100"
              >
                Discuss this service <ArrowUpRight size={15} aria-hidden="true" />
              </Link>
            </TiltCard>
          );
        })}
      </Reveal>

      {/* One shared canvas, portalled to <body> so page transforms can't displace it. */}
      {use3d &&
        createPortal(
          <div className="pointer-events-none fixed inset-0 z-[20]" aria-hidden="true">
            <ErrorBoundary onError={() => setFailed(true)} fallback={null}>
              <ServiceCanvas active={active} onDegrade={() => setFailed(true)} />
            </ErrorBoundary>
          </div>,
          document.body
        )}
    </div>
  );
}
