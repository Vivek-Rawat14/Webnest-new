"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { PerformanceMonitor, Points, PointMaterial } from "@react-three/drei";
import { look } from "@/lib/webgl";

const COLORS = ["#c9ccd3", "#7c5cff", "#5ce1ff", "#e9eaee"];

function rand(seed) {
  // deterministic so the layout is stable between renders
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function Field({ lite }) {
  const group = useRef();
  const camera = useThree((s) => s.camera);
  const items = useMemo(() => {
    const r = rand(42);
    const n = lite ? 10 : 18;
    return Array.from({ length: n }, (_, i) => ({
      p: [(r() - 0.5) * 18, -r() * 34 + 2, -3 - r() * 12],
      s: 0.5 + r() * 1.1,
      kind: i % 4,
      color: COLORS[i % COLORS.length],
      spin: [(r() - 0.5) * 0.4, (r() - 0.5) * 0.5],
    }));
  }, [lite]);

  const dust = useMemo(() => {
    const r = rand(7);
    const n = lite ? 220 : 520;
    const a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      a[i * 3] = (r() - 0.5) * 26;
      a[i * 3 + 1] = -r() * 40 + 4;
      a[i * 3 + 2] = -r() * 18;
    }
    return a;
  }, [lite]);

  useFrame((_, dt) => {
    const max = Math.max(document.documentElement.scrollHeight - window.innerHeight, 1);
    const p = Math.min(Math.max(window.scrollY / max, 0), 1);
    // The camera descends through the field as the page scrolls.
    camera.position.y = THREE.MathUtils.damp(camera.position.y, -p * 30, 3, dt);
    camera.position.x = THREE.MathUtils.damp(camera.position.x, look.x * 0.9, 2, dt);
    camera.rotation.y = THREE.MathUtils.damp(camera.rotation.y, -look.x * 0.05, 2, dt);
    camera.rotation.x = THREE.MathUtils.damp(camera.rotation.x, look.y * 0.03, 2, dt);
    group.current?.children.forEach((m, i) => {
      const it = items[i];
      if (!it) return;
      m.rotation.x += dt * it.spin[0];
      m.rotation.y += dt * it.spin[1];
    });
  });

  return (
    <>
      <group ref={group}>
        {items.map((it, i) => (
          <mesh key={i} position={it.p} scale={it.s}>
            {it.kind === 0 ? <icosahedronGeometry args={[1, 1]} /> : it.kind === 1 ? <torusGeometry args={[1, 0.05, 8, 64]} /> : it.kind === 2 ? <octahedronGeometry args={[1, 0]} /> : <boxGeometry args={[1.2, 1.2, 1.2]} />}
            <meshBasicMaterial color={it.color} wireframe transparent opacity={it.kind === 1 ? 0.5 : 0.22} />
          </mesh>
        ))}
      </group>
      <Points positions={dust} stride={3} frustumCulled={false}>
        <PointMaterial transparent color="#cfd3df" size={0.035} sizeAttenuation depthWrite={false} opacity={0.55} />
      </Points>
    </>
  );
}

export default function BackdropScene({ lite = false, active = true, onDegrade }) {
  return (
    <Canvas
      frameloop={active ? "always" : "never"}
      dpr={1}
      camera={{ position: [0, 0, 6], fov: 55 }}
      gl={{ antialias: false, alpha: true, powerPreference: "low-power" }}
    >
      {/* Struggling device (sustained < ~18 fps): drop the decorative layer entirely. */}
      <PerformanceMonitor bounds={() => [18, 60]} iterations={8} onDecline={onDegrade} />
      <fog attach="fog" args={["#050506", 6, 22]} />
      <Field lite={lite} />
    </Canvas>
  );
}
