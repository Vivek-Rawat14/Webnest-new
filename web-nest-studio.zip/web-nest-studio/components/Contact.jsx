"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, Loader2, Mail, MessageCircle, ArrowUpRight, AlertCircle } from "lucide-react";
import { Reveal, SplitReveal } from "./Reveal";
import { services } from "@/lib/data";
import { site } from "@/lib/site";

const projectTypes = [...services.map((s) => ({ id: s.id, label: s.title })), { id: "other", label: "Something else" }];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validate(v) {
  const e = {};
  if (v.name.trim().length < 2) e.name = "Please enter your name.";
  if (!EMAIL_RE.test(v.email.trim())) e.email = "Please enter a valid email address.";
  if (!v.type) e.type = "Please choose a project type.";
  if (v.message.trim().length < 10) e.message = "Tell me a little more (at least 10 characters).";
  if (v.message.length > 3000) e.message = "Message is too long (3000 characters max).";
  if (v.budget.length > 80) e.budget = "Keep the budget note under 80 characters.";
  return e;
}

function Field({ id, label, optional, error, children }) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 flex items-baseline justify-between text-sm text-silver">
        <span>{label}</span>
        {optional && <span className="text-xs text-mist">Optional</span>}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-2 flex items-center gap-1.5 text-xs text-rose-300">
          <AlertCircle size={13} aria-hidden="true" /> {error}
        </p>
      )}
    </div>
  );
}

const input =
  "w-full rounded-xl border border-white/12 bg-white/[0.04] px-4 py-3.5 text-base text-white placeholder:text-mist/70 transition focus:border-white/50 focus:bg-white/[0.07] aria-[invalid=true]:border-rose-400/70";

export default function Contact({ heading = "h2" }) {
  const [values, setValues] = useState({ name: "", email: "", type: "", budget: "", message: "", website: "" });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | sending | sent | mailto | error
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("service");
    if (s && projectTypes.some((p) => p.id === s)) setValues((v) => ({ ...v, type: s }));
  }, []);

  const set = (k) => (e) => {
    const val = e.target.value;
    setValues((v) => ({ ...v, [k]: val }));
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const errs = validate(values);
    setErrors(errs);
    if (Object.keys(errs).length) {
      document.getElementById(`c-${Object.keys(errs)[0]}`)?.focus();
      return;
    }
    setStatus("sending");
    setServerError("");
    const typeLabel = projectTypes.find((p) => p.id === values.type)?.label || values.type;
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...values, typeLabel }),
      });
      if (res.ok) {
        setStatus("sent");
        return;
      }
      const data = await res.json().catch(() => ({}));
      if (res.status === 503 && data.error === "not_configured") {
        // Delivery is not configured on the server: hand off to the visitor's email app instead.
        const body = `Name: ${values.name}\nEmail: ${values.email}\nProject type: ${typeLabel}\nBudget: ${values.budget || "-"}\n\n${values.message}`;
        window.location.href = `mailto:${site.email}?subject=${encodeURIComponent(`Project enquiry: ${typeLabel}`)}&body=${encodeURIComponent(body)}`;
        setStatus("mailto");
        return;
      }
      if (data.fields) setErrors(data.fields);
      throw new Error(data.message || "Something went wrong. Please try again.");
    } catch (err) {
      setServerError(err.message || "Something went wrong. Please try again.");
      setStatus("error");
    }
  };

  const done = status === "sent" || status === "mailto";

  return (
    <div className="grid gap-14 lg:grid-cols-[.9fr_1.1fr]">
      <div>
        <Reveal y={16}>
          <p className="eyebrow mb-5 flex items-center gap-3">
            <span className="h-px w-8 bg-white/30" aria-hidden="true" />
            Contact
          </p>
        </Reveal>
        <SplitReveal
          as={heading}
          text="Have a Project in Mind? Let's Build Something Extraordinary."
          className="h-display text-[clamp(2.1rem,5.2vw,4rem)] text-white"
          lineBreakAfter={[4]}
        />

        <Reveal delay={0.2} stagger={0.1} className="mt-10 space-y-3" y={20}>
          <a href={`mailto:${site.email}`} className="group panel flex min-h-[64px] items-center gap-4 rounded-2xl p-4 transition hover:border-white/30">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 text-white">
              <Mail size={19} aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-xs text-mist">Email</span>
              <span className="block truncate text-sm text-white">{site.email}</span>
            </span>
            <ArrowUpRight size={17} className="text-mist transition group-hover:text-white" aria-hidden="true" />
          </a>
          <a
            href={site.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group panel flex min-h-[64px] items-center gap-4 rounded-2xl p-4 transition hover:border-white/30"
          >
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 text-white">
              <MessageCircle size={19} aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-xs text-mist">WhatsApp</span>
              <span className="block truncate text-sm text-white">+{site.whatsapp}</span>
            </span>
            <ArrowUpRight size={17} className="text-mist transition group-hover:text-white" aria-hidden="true" />
          </a>
          <div className="flex flex-wrap gap-2 pt-2">
            {site.socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                className="glass inline-flex min-h-[44px] items-center gap-1.5 rounded-full px-4 text-sm text-silver transition hover:text-white"
              >
                {s.label} <ArrowUpRight size={13} aria-hidden="true" />
              </a>
            ))}
          </div>
          {(site.emailIsPlaceholder || site.whatsappIsPlaceholder) && (
            <p className="pt-2 text-xs text-mist">Contact details shown here are placeholders until real ones are added.</p>
          )}
        </Reveal>
      </div>

      <Reveal delay={0.1}>
        <div className="panel relative overflow-hidden rounded-3xl p-6 sm:p-9">
          {done ? (
            <div className="flex min-h-[420px] flex-col items-center justify-center text-center" role="status">
              <CheckCircle2 size={48} className="text-emerald-400" aria-hidden="true" />
              <h3 className="h-display mt-6 text-3xl text-white">{status === "sent" ? "Message sent." : "Almost there."}</h3>
              <p className="mt-3 max-w-sm text-sm leading-relaxed text-mist">
                {status === "sent"
                  ? "Thanks for reaching out. I'll get back to you by email."
                  : "Your email app should have opened with your message ready. Press send there to reach the studio."}
              </p>
              <button type="button" className="btn btn-ghost mt-8" onClick={() => setStatus("idle")}>
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-5" aria-label="Project enquiry form">
              <div className="grid gap-5 sm:grid-cols-2">
                <Field id="c-name" label="Name" error={errors.name}>
                  <input id="c-name" name="name" autoComplete="name" value={values.name} onChange={set("name")} className={input} placeholder="Your name" aria-invalid={!!errors.name} aria-describedby={errors.name ? "c-name-error" : undefined} required />
                </Field>
                <Field id="c-email" label="Email" error={errors.email}>
                  <input id="c-email" name="email" type="email" autoComplete="email" inputMode="email" value={values.email} onChange={set("email")} className={input} placeholder="you@example.com" aria-invalid={!!errors.email} aria-describedby={errors.email ? "c-email-error" : undefined} required />
                </Field>
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field id="c-type" label="Project type" error={errors.type}>
                  <select id="c-type" name="type" value={values.type} onChange={set("type")} className={`${input} appearance-none`} aria-invalid={!!errors.type} aria-describedby={errors.type ? "c-type-error" : undefined} required>
                    <option value="" className="bg-coal">Select a type</option>
                    {projectTypes.map((p) => (
                      <option key={p.id} value={p.id} className="bg-coal">
                        {p.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field id="c-budget" label="Budget" optional error={errors.budget}>
                  <input id="c-budget" name="budget" value={values.budget} onChange={set("budget")} className={input} placeholder="Your estimated budget" aria-invalid={!!errors.budget} aria-describedby={errors.budget ? "c-budget-error" : undefined} />
                </Field>
              </div>
              <Field id="c-message" label="Message" error={errors.message}>
                <textarea id="c-message" name="message" rows={5} value={values.message} onChange={set("message")} className={`${input} resize-y`} placeholder="Tell me about your project, goals and timeline." aria-invalid={!!errors.message} aria-describedby={errors.message ? "c-message-error" : undefined} required />
              </Field>

              {/* honeypot: hidden from people, tempting to bots */}
              <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
                <label>
                  Website
                  <input tabIndex={-1} autoComplete="off" name="website" value={values.website} onChange={set("website")} />
                </label>
              </div>

              {status === "error" && (
                <p role="alert" className="flex items-center gap-2 rounded-xl border border-rose-400/30 bg-rose-400/10 p-3 text-sm text-rose-200">
                  <AlertCircle size={16} aria-hidden="true" /> {serverError}
                </p>
              )}

              <button type="submit" disabled={status === "sending"} className="btn btn-primary w-full disabled:opacity-70" data-cursor="Send">
                {status === "sending" ? (
                  <>
                    <Loader2 size={17} className="animate-spin" aria-hidden="true" /> Sending...
                  </>
                ) : (
                  "Send Message"
                )}
              </button>
            </form>
          )}
        </div>
      </Reveal>
    </div>
  );
}
