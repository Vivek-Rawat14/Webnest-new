"use client";

import { Component } from "react";

/** Keeps a failing 3D scene from taking the page down; renders the supplied fallback instead. */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(err) {
    this.props.onError?.(err);
    if (process.env.NODE_ENV !== "production") console.warn("3D scene failed:", err?.message);
  }
  render() {
    return this.state.failed ? this.props.fallback ?? null : this.props.children;
  }
}
