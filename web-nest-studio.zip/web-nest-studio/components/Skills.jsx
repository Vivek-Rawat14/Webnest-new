"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import dynamic from "next/dynamic";
import TiltCard from "./TiltCard";
import InView3D from "./InView3D";
import { Reveal } from "./Reveal";
import { skills } from "@/lib/data";

const SkillsSphere = dynamic(() => import("./SkillsSphere"), { ssr: false });

const glyph = (n) =>
  ({ "Tailwind CSS": "TW", "Shopify Liquid": "{ }", "App Development": "APP", "Node.js": "JS", "Next.js": "N", "Three.js": "3D" })[n] ||
  n.replace(/[^A-Za-z]/g, "").slice(0, 2).toUpperCase();

export default function Skills() {
  const groups = useMemo(() => ["All", ...Array.from(new Set(skills.map((s) => s.group)))], []);
  const [group, setGroup] = useState("All");
  const shown = skills.filter((s) => group === "All" || s.group === group);

  return (
    <div>
      {/* interactive 3D globe of technologies (the filterable cards below stay available for everyone) */}
      <InView3D className="relative mx-auto mb-12 h-[380px] w-full max-w-3xl sm:h-[520px]" fallback={null}>
        {({ active, lite }) => (
          <div className="h-full w-full" role="img" aria-label="3D globe of technologies: HTML, CSS, JavaScript, React, Next.js, Shopify, WordPress and more">
            <SkillsSphere active={active} lite={lite} />
          </div>
        )}
      </InView3D>

      <Reveal className="mb-8 flex flex-wrap gap-2" y={16}>
        {groups.map((g) => (
          <button
            key={g}
            type="button"
            onClick={() => setGroup(g)}
            aria-pressed={group === g}
            className={`min-h-[40px] rounded-full border px-4 text-xs transition ${
              group === g ? "border-white bg-white text-ink" : "border-white/15 text-silver hover:border-white/40 hover:text-white"
            }`}
          >
            {g}
          </button>
        ))}
      </Reveal>

      <motion.ul layout className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
        <AnimatePresence mode="popLayout">
          {shown.map((s) => (
            <motion.li
              key={s.name}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.4, ease: [0.2, 0.8, 0.2, 1] }}
            >
              <TiltCard className="group panel flex h-full min-h-[140px] flex-col justify-between overflow-hidden rounded-2xl p-5 hover:border-white/25" max={10}>
                <span
                  className="font-display text-3xl font-bold text-white/15 transition-colors duration-500 group-hover:text-white/40"
                  style={{ transform: "translateZ(40px)" }}
                  aria-hidden="true"
                >
                  {glyph(s.name)}
                </span>
                <div style={{ transform: "translateZ(20px)" }}>
                  <p className="text-sm font-semibold text-white sm:text-base">{s.name}</p>
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.2em] text-mist">{s.group}</p>
                </div>
              </TiltCard>
            </motion.li>
          ))}
        </AnimatePresence>
      </motion.ul>
    </div>
  );
}
