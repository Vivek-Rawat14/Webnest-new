import { Reveal, SplitReveal } from "./Reveal";

export default function PageHeader({ eyebrow, title, text }) {
  return (
    <header className="relative overflow-hidden px-5 pb-12 pt-36 sm:px-8 sm:pb-16 sm:pt-44">
      <div
        className="pointer-events-none absolute inset-0 -z-10"
        style={{ background: "radial-gradient(50% 60% at 80% 0%, rgba(124,92,255,.14), transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="mx-auto max-w-6xl">
        <Reveal y={14}>
          <p className="eyebrow mb-6 flex items-center gap-3">
            <span className="h-px w-8 bg-white/30" aria-hidden="true" />
            {eyebrow}
          </p>
        </Reveal>
        <SplitReveal as="h1" gate text={title} className="h-display max-w-4xl text-[clamp(2.4rem,7vw,5.2rem)] text-white" />
        {text && (
          <Reveal gate delay={0.3} className="mt-7 max-w-2xl text-base leading-relaxed text-silver/80 sm:text-lg">
            <p>{text}</p>
          </Reveal>
        )}
      </div>
    </header>
  );
}
