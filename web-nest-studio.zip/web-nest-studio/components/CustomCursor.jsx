"use client";

import { useEffect, useRef, useState } from "react";

/** Desktop-only cursor: a dot plus a trailing ring that grows over interactive elements.
 *  Any element with data-cursor="Label" shows that label in the ring. */
export default function CustomCursor() {
  const dot = useRef(null);
  const ring = useRef(null);
  const [label, setLabel] = useState("");
  const [hover, setHover] = useState(false);

  useEffect(() => {
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduce) return;
    document.documentElement.classList.add("has-cursor");

    let x = -100,
      y = -100,
      rx = -100,
      ry = -100,
      raf = 0;
    const move = (e) => {
      x = e.clientX;
      y = e.clientY;
      if (dot.current) dot.current.style.transform = `translate3d(${x}px,${y}px,0)`;
      const el = e.target instanceof Element ? e.target.closest("[data-cursor],a,button,[role='button'],input,textarea,select") : null;
      setHover(!!el);
      setLabel(el?.getAttribute?.("data-cursor") || "");
    };
    const tick = () => {
      rx += (x - rx) * 0.16;
      ry += (y - ry) * 0.16;
      if (ring.current) ring.current.style.transform = `translate3d(${rx}px,${ry}px,0)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      window.removeEventListener("pointermove", move);
      cancelAnimationFrame(raf);
      document.documentElement.classList.remove("has-cursor");
    };
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed left-0 top-0 z-[90] hidden [@media(hover:hover)_and_(pointer:fine)]:block">
      <div ref={dot} className="fixed left-0 top-0 -ml-[3px] -mt-[3px] h-[6px] w-[6px] rounded-full bg-white mix-blend-difference" />
      <div ref={ring} className="fixed left-0 top-0">
        <div
          className={`-ml-1/2 grid place-items-center rounded-full border border-white/70 text-[10px] font-semibold uppercase tracking-widest text-ink transition-all duration-300 ${
            label ? "bg-white" : hover ? "bg-white/15 backdrop-blur-sm" : "bg-transparent"
          }`}
          style={{
            width: label ? 84 : hover ? 54 : 34,
            height: label ? 84 : hover ? 54 : 34,
            marginLeft: label ? -42 : hover ? -27 : -17,
            marginTop: label ? -42 : hover ? -27 : -17,
          }}
        >
          {label}
        </div>
      </div>
    </div>
  );
}
