"use client";

import dynamic from "next/dynamic";
import { Reveal, SplitReveal, Parallax } from "./Reveal";
import { LogoMark } from "./Logo";
import InView3D from "./InView3D";
import { aboutPoints } from "@/lib/data";

const LogoScene = dynamic(() => import("./LogoScene"), { ssr: false });

// Static illustration: shown while the 3D logo loads, and when WebGL is unavailable.
function Illustration2D() {
  return (
    <div className="relative grid h-full w-full place-items-center" aria-hidden="true">
      <div className="absolute inset-[4%] rounded-full border border-white/10" style={{ animation: "spin-slow 60s linear infinite" }}>
        <span className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full bg-volt shadow-[0_0_20px_#7c5cff]" />
      </div>
      <div className="absolute inset-[16%] rounded-full border border-dashed border-white/15" style={{ animation: "spin-slow 40s linear infinite reverse" }}>
        <span className="absolute -bottom-1 left-1/2 h-2 w-2 -translate-x-1/2 rounded-full bg-ice shadow-[0_0_16px_#5ce1ff]" />
      </div>
      <div className="absolute inset-[30%] rounded-full border border-white/10" style={{ animation: "spin-slow 28s linear infinite" }} />
      <div className="absolute inset-[18%] rounded-full bg-[radial-gradient(circle,rgba(124,92,255,.22),transparent_70%)] blur-2xl" />
      <div style={{ animation: "floaty 7s ease-in-out infinite" }}>
        <LogoMark size={150} />
      </div>
    </div>
  );
}

export default function About({ heading = "h2" }) {
  return (
    <div className="grid items-center gap-14 overflow-x-clip lg:grid-cols-[1.1fr_.9fr]">
      <div>
        <Reveal y={16}>
          <p className="eyebrow mb-5 flex items-center gap-3">
            <span className="h-px w-8 bg-white/30" aria-hidden="true" />
            About
          </p>
        </Reveal>
        <SplitReveal as={heading} text="Turning Ideas Into Digital Experiences." className="h-display text-[clamp(2.2rem,6vw,4.6rem)] text-white" />
        <Reveal delay={0.2} className="mt-8 max-w-xl text-base leading-relaxed text-silver/85 sm:text-lg">
          <p>
            I&apos;m a freelance web developer focused on building modern websites, eCommerce experiences and digital products that
            combine thoughtful design with powerful functionality.
          </p>
        </Reveal>
        <Reveal stagger={0.07} className="mt-10 flex flex-wrap gap-2.5" y={20}>
          {aboutPoints.map((p) => (
            <span key={p} className="glass rounded-full px-4 py-2 text-sm text-silver">
              {p}
            </span>
          ))}
        </Reveal>
      </div>

      {/* interactive 3D studio mark; follows the pointer */}
      <Parallax speed={4} className="relative mx-auto aspect-square w-full max-w-[460px]">
        <InView3D className="h-full w-full" fallback={<Illustration2D />}>
          {({ active, lite }) => (
            <div className="h-full w-full" role="img" aria-label="Interactive 3D Web Nest Studio logo">
              <LogoScene active={active} lite={lite} />
            </div>
          )}
        </InView3D>
      </Parallax>
    </div>
  );
}
