"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Volume2, VolumeX, SkipForward } from "lucide-react";
import Logo from "./Logo";
import { registerGsap, prefersReducedMotion } from "@/lib/gsap";
import { markIntroDone, REPLAY_EVENT } from "@/lib/introGate";
import { site } from "@/lib/site";

const SEEN_KEY = "wns-intro-seen";

/**
 * Cinematic logo reveal (~4.4s). Shown once per session, skippable, replayable.
 * Never blocks the site: every failure path ends in finish().
 */
export default function Intro() {
  const [phase, setPhase] = useState("pending"); // pending | playing | done
  const [sound, setSound] = useState(false);
  const rootRef = useRef(null);
  const canvasRef = useRef(null);
  const tlRef = useRef(null);
  const audioRef = useRef(null);
  const rafRef = useRef(0);
  const failsafe = useRef(null);

  const unlock = useCallback((lock) => {
    document.documentElement.classList.toggle("intro-lock", lock);
  }, []);

  const finish = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    clearTimeout(failsafe.current);
    tlRef.current?.kill();
    const a = audioRef.current;
    if (a) {
      try {
        a.pause();
      } catch {}
    }
    try {
      sessionStorage.setItem(SEEN_KEY, "1");
    } catch {}
    unlock(false);
    setPhase("done");
    markIntroDone();
  }, [unlock]);

  const start = useCallback(
    (replay = false) => {
      setPhase("playing");
      unlock(true);
      failsafe.current = setTimeout(finish, 9000);
      if (replay) window.scrollTo(0, 0);
    },
    [finish, unlock]
  );

  // Decide whether to play.
  useEffect(() => {
    let seen = false;
    try {
      seen = sessionStorage.getItem(SEEN_KEY) === "1";
    } catch {}
    if (seen) {
      setPhase("done");
      markIntroDone();
    } else {
      start(false);
    }
    const onReplay = () => start(true);
    window.addEventListener(REPLAY_EVENT, onReplay);
    return () => window.removeEventListener(REPLAY_EVENT, onReplay);
  }, [start]);

  // Escape skips.
  useEffect(() => {
    if (phase !== "playing") return;
    const onKey = (e) => e.key === "Escape" && finish();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, finish]);

  // Particles (light 2D canvas).
  useEffect(() => {
    if (phase !== "playing" || prefersReducedMotion()) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const count = w < 640 ? 46 : 90;
    const parts = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.6 + 0.3,
      vx: (Math.random() - 0.5) * 0.15,
      vy: -Math.random() * 0.35 - 0.05,
      a: Math.random() * 0.6 + 0.15,
    }));
    const t0 = performance.now();
    const loop = (now) => {
      const t = (now - t0) / 1000;
      ctx.clearRect(0, 0, w, h);
      // Particles converge gently toward the logo as it forms.
      const pull = Math.min(Math.max((t - 1.2) / 1.6, 0), 1) * 0.0009;
      for (const p of parts) {
        p.x += p.vx + (w / 2 - p.x) * pull;
        p.y += p.vy + (h / 2 - p.y) * pull;
        if (p.y < -5) p.y = h + 5;
        ctx.beginPath();
        ctx.fillStyle = `rgba(210,214,224,${p.a})`;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
    };
  }, [phase]);

  // The timeline.
  useEffect(() => {
    if (phase !== "playing") return;
    const root = rootRef.current;
    if (!root) return;
    const { gsap } = registerGsap();
    const reduce = prefersReducedMotion();

    const ctx = gsap.context(() => {
      const q = (s) => root.querySelectorAll(s);
      const paths = q("[data-draw]");
      const node = q("[data-node]");

      if (reduce) {
        gsap.set(paths, { strokeDasharray: 1, strokeDashoffset: 0 });
        const tl = gsap.timeline({ onComplete: finish });
        tlRef.current = tl;
        tl.fromTo(q("[data-stage]"), { opacity: 0 }, { opacity: 1, duration: 0.5 })
          .fromTo(q("[data-tagline]"), { opacity: 0 }, { opacity: 1, duration: 0.4 }, 0.3)
          .to({}, { duration: 0.7 })
          .to(root, { opacity: 0, duration: 0.4 });
        return;
      }

      gsap.set(paths, { strokeDasharray: 1, strokeDashoffset: 1 });
      gsap.set(node, { scale: 0, transformOrigin: "50% 50%" });
      gsap.set(q(".logo-word"), { opacity: 0, letterSpacing: "0.9em" });
      gsap.set(q(".logo-sub"), { opacity: 0, letterSpacing: "1.3em" });
      gsap.set(q("[data-tagline]"), { opacity: 0, y: 14 });
      gsap.set(q("[data-sweep]"), { xPercent: -140 });
      gsap.set(q("[data-glow]"), { opacity: 0, scale: 0.6 });
      gsap.set(q("[data-stage]"), { opacity: 1, rotateY: 28, rotateX: -8, scale: 0.9, transformPerspective: 900 });

      const tl = gsap.timeline({ onComplete: finish, defaults: { ease: "power3.out" } });
      tlRef.current = tl;
      tl.to(q("[data-glow]"), { opacity: 1, scale: 1, duration: 1.6, ease: "power2.out" }, 0.2)
        .to(paths, { strokeDashoffset: 0, duration: 1.3, stagger: 0.22, ease: "power2.inOut" }, 0.45)
        .to(node, { scale: 1, duration: 0.6, ease: "back.out(3)" }, 1.55)
        .to(q("[data-stage]"), { rotateY: 0, rotateX: 0, scale: 1, duration: 2.2, ease: "power3.out" }, 0.4)
        .to(q("[data-sweep]"), { xPercent: 140, duration: 1.1, ease: "power2.inOut" }, 1.7)
        .to(q(".logo-word"), { opacity: 1, letterSpacing: "0.42em", duration: 1.2 }, 1.85)
        .to(q(".logo-sub"), { opacity: 1, letterSpacing: "0.7em", duration: 1.1 }, 2.1)
        .to(q("[data-tagline]"), { opacity: 1, y: 0, duration: 0.9 }, 2.55)
        .to({}, { duration: 0.75 })
        .to(q("[data-stage],[data-tagline]"), { opacity: 0, scale: 1.06, duration: 0.55, ease: "power2.in" })
        .to(root, { opacity: 0, duration: 0.55, ease: "power2.inOut" }, "-=0.25");
    }, root);

    return () => ctx.revert();
  }, [phase, finish]);

  // Optional sound: only after the visitor asks for it (autoplay policies).
  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    try {
      if (!audioRef.current) {
        audioRef.current = new Audio("/audio/intro.mp3");
        audioRef.current.volume = 0.7;
      }
      const a = audioRef.current;
      if (next) {
        a.currentTime = Math.min(tlRef.current?.time() || 0, 4);
        a.play().catch(() => setSound(false));
      } else {
        a.pause();
      }
    } catch {
      setSound(false);
    }
  };

  if (phase === "done") return null;

  return (
    <div
      ref={rootRef}
      className="intro-root fixed inset-0 z-[100] overflow-hidden bg-ink"
      role="dialog"
      aria-label="Web Nest Studio intro"
      aria-busy={phase === "pending"}
    >
      <noscript>
        <style>{`.intro-root{display:none!important}`}</style>
      </noscript>

      {phase === "playing" && (
        <>
          <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-hidden="true" />
          <div
            data-glow
            className="pointer-events-none absolute left-1/2 top-1/2 h-[60vmin] w-[60vmin] -translate-x-1/2 -translate-y-1/2 rounded-full"
            style={{
              background:
                "radial-gradient(circle, rgba(124,92,255,.22) 0%, rgba(92,225,255,.08) 38%, transparent 68%)",
            }}
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center px-6">
            <div data-stage className="relative overflow-hidden px-10 py-8" style={{ opacity: 0 }}>
              <Logo variant="stacked" animate size={112} />
              <div
                data-sweep
                className="pointer-events-none absolute inset-y-0 left-0 w-1/2 -skew-x-12"
                style={{
                  background: "linear-gradient(90deg, transparent, rgba(255,255,255,.55), transparent)",
                  mixBlendMode: "overlay",
                }}
              />
            </div>
            <p
              data-tagline
              className="mt-8 max-w-[26rem] text-center font-sans text-sm leading-relaxed text-silver sm:text-base"
              style={{ opacity: 0 }}
            >
              {site.tagline}
            </p>
          </div>

          <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-5 sm:p-8">
            <button
              type="button"
              onClick={toggleSound}
              aria-pressed={sound}
              className="glass inline-flex min-h-[44px] items-center gap-2 rounded-full px-4 text-xs text-silver transition hover:text-white"
            >
              {sound ? <Volume2 size={15} aria-hidden="true" /> : <VolumeX size={15} aria-hidden="true" />}
              {sound ? "Sound on" : "Enable sound"}
            </button>
            <button
              type="button"
              onClick={finish}
              className="glass inline-flex min-h-[44px] items-center gap-2 rounded-full px-4 text-xs text-silver transition hover:text-white"
            >
              Skip intro <SkipForward size={15} aria-hidden="true" />
            </button>
          </div>
        </>
      )}
    </div>
  );
}
