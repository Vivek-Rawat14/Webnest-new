"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import ErrorBoundary from "./ErrorBoundary";

function StaticOrb() {
  return (
    <div className="absolute inset-0" aria-hidden="true">
      <div className="static-orb" style={{ transform: "translateX(18%)" }} />
    </div>
  );
}

// Heavy 3D code is split out and never rendered on the server.
const HeroScene = dynamic(() => import("./HeroScene"), { ssr: false, loading: () => <StaticOrb /> });

function hasWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

export default function HeroVisual() {
  const ref = useRef(null);
  const [mode, setMode] = useState("pending"); // pending | webgl | static
  const [active, setActive] = useState(true);
  const [lite, setLite] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const weak = (navigator.hardwareConcurrency || 4) <= 4 || window.innerWidth < 768;
    setLite(weak);
    setMode(!reduce && hasWebGL() ? "webgl" : "static");
  }, []);

  // Pause rendering when the hero is off-screen or the tab is hidden.
  useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => setActive(e.isIntersecting), { threshold: 0 });
    io.observe(ref.current);
    const vis = () => setActive(!document.hidden);
    document.addEventListener("visibilitychange", vis);
    return () => {
      io.disconnect();
      document.removeEventListener("visibilitychange", vis);
    };
  }, []);

  return (
    <div ref={ref} className="absolute inset-0" aria-hidden="true">
      {mode === "webgl" ? (
        <ErrorBoundary fallback={<StaticOrb />}>
          <HeroScene active={active} lite={lite} />
        </ErrorBoundary>
      ) : mode === "static" ? (
        <StaticOrb />
      ) : null}
    </div>
  );
}
