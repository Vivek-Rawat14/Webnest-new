"use client";

import { useEffect, useRef, useState } from "react";
import ErrorBoundary from "./ErrorBoundary";
import { canUse3D, isLiteDevice } from "@/lib/webgl";

/**
 * Mounts a 3D scene only when it is near the viewport, pauses it when it scrolls away,
 * and shows `fallback` when WebGL is missing, motion is reduced, or the scene throws.
 * children: ({ active, lite }) => <Canvas/>
 */
export default function InView3D({ children, fallback = null, className = "", rootMargin = "300px" }) {
  const ref = useRef(null);
  const [ok, setOk] = useState(false);
  const [seen, setSeen] = useState(false);
  const [active, setActive] = useState(false);
  const [lite, setLite] = useState(true);

  useEffect(() => {
    setOk(canUse3D());
    setLite(isLiteDevice());
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        setActive(e.isIntersecting);
        if (e.isIntersecting) setSeen(true);
      },
      { rootMargin }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [rootMargin]);

  return (
    <div ref={ref} className={className}>
      {ok && seen ? <ErrorBoundary fallback={fallback}>{children({ active, lite })}</ErrorBoundary> : fallback}
    </div>
  );
}
