const items = ["Shopify", "Full-Stack", "WordPress", "App Development", "Creative Web", "eCommerce", "Custom Websites"];

export default function Marquee() {
  const row = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-white/10 bg-coal/50 py-5" aria-hidden="true">
      <div className="marquee-track">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center">
            {row.map((t, i) => (
              <span key={`${k}-${i}`} className="flex items-center">
                <span className="h-display px-8 text-3xl text-white/15 sm:text-5xl">{t}</span>
                <span className="text-mist/50">&#10022;</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
