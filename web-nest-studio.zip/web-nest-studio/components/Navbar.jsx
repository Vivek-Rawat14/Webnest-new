"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import Logo from "./Logo";
import { navLinks } from "@/lib/site";

// On the home page the menu scrolls to sections (with scroll-spy); elsewhere it links to pages.
const sectionFor = { Home: "home", Work: "work", About: "about", Services: "services", Contact: "contact" };

function Availability({ className = "" }) {
  return (
    <span className={`inline-flex items-center gap-2 text-[11px] text-silver ${className}`}>
      <span className="relative flex h-2 w-2" aria-hidden="true">
        <span className="absolute inline-flex h-full w-full animate-pulseDot rounded-full bg-emerald-400" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
      </span>
      Available for freelance
    </span>
  );
}

export default function Navbar() {
  const pathname = usePathname();
  const onHome = pathname === "/";
  const [open, setOpen] = useState(false);
  const [spy, setSpy] = useState("home");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Scroll-spy for the home page.
  useEffect(() => {
    if (!onHome) return;
    const ids = Object.values(sectionFor);
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (vis) setSpy(vis.target.id);
      },
      { rootMargin: "-35% 0px -55% 0px", threshold: [0, 0.2, 0.5] }
    );
    const attach = () =>
      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el) io.observe(el);
      });
    attach();
    const t = setTimeout(attach, 800);
    return () => {
      clearTimeout(t);
      io.disconnect();
    };
  }, [onHome]);

  useEffect(() => {
    document.documentElement.classList.toggle("intro-lock", open);
    return () => document.documentElement.classList.remove("intro-lock");
  }, [open]);

  const isActive = (l) => {
    if (onHome) return spy === sectionFor[l.label];
    if (l.href === "/") return false;
    return pathname === l.href || pathname.startsWith(l.href + "/");
  };
  const hrefFor = (l) => (onHome ? `#${sectionFor[l.label]}` : l.href);

  return (
    <>
      <header className="pointer-events-none fixed inset-x-0 top-0 z-50 flex justify-center px-3 pt-3 sm:px-6 sm:pt-5">
        <motion.nav
          aria-label="Primary"
          initial={{ y: -80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.9, ease: [0.2, 0.8, 0.2, 1], delay: 0.2 }}
          className={`glass pointer-events-auto flex w-full max-w-6xl items-center justify-between rounded-full py-2 pl-4 pr-2 transition-all duration-500 sm:pl-5 ${
            scrolled ? "shadow-[0_10px_40px_-10px_rgba(0,0,0,.8)]" : ""
          }`}
        >
          <Link href="/" aria-label="Web Nest Studio home" className="shrink-0">
            <span className="hidden sm:block">
              <Logo variant="full" size={34} />
            </span>
            <span className="sm:hidden">
              <Logo variant="compact" size={28} />
            </span>
          </Link>

          <ul className="relative hidden items-center gap-1 lg:flex">
            {navLinks.map((l) => {
              const active = isActive(l);
              return (
                <li key={l.label} className="relative">
                  <Link
                    href={hrefFor(l)}
                    aria-current={active ? "page" : undefined}
                    className={`relative z-10 block rounded-full px-4 py-2 text-sm transition-colors ${
                      active ? "text-white" : "text-mist hover:text-white"
                    }`}
                  >
                    {l.label}
                  </Link>
                  {active && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 rounded-full bg-white/10 ring-1 ring-white/15"
                      transition={{ type: "spring", stiffness: 420, damping: 36 }}
                    />
                  )}
                </li>
              );
            })}
          </ul>

          <div className="flex items-center gap-2">
            <Availability className="hidden xl:inline-flex" />
            <Link href="/contact" className="btn btn-primary hidden !min-h-[40px] !px-5 !py-2 text-sm sm:inline-flex">
              Start a project
            </Link>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="grid h-11 w-11 place-items-center rounded-full border border-white/15 text-white lg:hidden"
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </motion.nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            role="dialog"
            aria-label="Menu"
            initial={{ clipPath: "circle(0% at calc(100% - 40px) 40px)" }}
            animate={{ clipPath: "circle(150% at calc(100% - 40px) 40px)" }}
            exit={{ clipPath: "circle(0% at calc(100% - 40px) 40px)" }}
            transition={{ duration: 0.7, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 z-40 flex flex-col justify-between bg-ink px-6 pb-8 pt-28 lg:hidden"
          >
            <ul className="space-y-1">
              {navLinks.map((l, i) => (
                <motion.li
                  key={l.label}
                  initial={{ y: 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.25 + i * 0.07, duration: 0.6, ease: [0.2, 0.8, 0.2, 1] }}
                >
                  <Link
                    href={hrefFor(l)}
                    onClick={() => setOpen(false)}
                    aria-current={isActive(l) ? "page" : undefined}
                    className="flex items-baseline gap-4 border-b border-white/10 py-4 font-display text-[2.4rem] font-bold leading-none tracking-tight text-white"
                  >
                    <span className="font-mono text-xs text-mist">0{i + 1}</span>
                    <span className={isActive(l) ? "text-silver-gradient" : ""}>{l.label}</span>
                  </Link>
                </motion.li>
              ))}
            </ul>
            <div className="space-y-5">
              <Availability />
              <Link href="/contact" onClick={() => setOpen(false)} className="btn btn-primary w-full">
                Start a project
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
