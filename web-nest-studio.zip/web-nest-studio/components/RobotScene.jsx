"use client";

import { useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, Lightformer, RoundedBox } from "@react-three/drei";

// Normalised pointer, shared by every robot instance (the canvas itself ignores pointer events).
const look = { x: 0, y: 0 };
if (typeof window !== "undefined" && !window.__wnsLook) {
  window.__wnsLook = true;
  window.addEventListener(
    "pointermove",
    (e) => {
      look.x = (e.clientX / window.innerWidth) * 2 - 1;
      look.y = -((e.clientY / window.innerHeight) * 2 - 1);
    },
    { passive: true }
  );
}

function Robot({ talking, lite }) {
  const head = useRef();
  const eyeL = useRef();
  const eyeR = useRef();
  const mouth = useRef();
  const ant = useRef();
  const armL = useRef();
  const armR = useRef();
  const blink = useRef(0);
  const nextBlink = useRef(1.5);

  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    if (head.current) {
      head.current.rotation.y = THREE.MathUtils.damp(head.current.rotation.y, look.x * 0.55, 4, dt);
      head.current.rotation.x = THREE.MathUtils.damp(head.current.rotation.x, -look.y * 0.3, 4, dt);
    }
    // blinking
    nextBlink.current -= dt;
    if (nextBlink.current < 0) {
      blink.current = 0.14;
      nextBlink.current = 2 + Math.random() * 3;
    }
    blink.current = Math.max(0, blink.current - dt);
    const eyeScaleY = blink.current > 0 ? 0.08 : 1;
    [eyeL, eyeR].forEach((r) => {
      if (r.current) r.current.scale.y = THREE.MathUtils.damp(r.current.scale.y, eyeScaleY, 30, dt);
    });
    if (mouth.current) {
      const target = talking ? 0.35 + Math.abs(Math.sin(t * 14)) * 0.9 : 0.25;
      mouth.current.scale.y = THREE.MathUtils.damp(mouth.current.scale.y, target, 18, dt);
    }
    if (ant.current) ant.current.rotation.z = Math.sin(t * 2) * 0.15;
    if (armL.current) armL.current.position.y = -1.05 + Math.sin(t * 2.2) * 0.07;
    if (armR.current) armR.current.position.y = -1.05 + Math.sin(t * 2.2 + 1.6) * 0.07;
  });

  return (
    <Float speed={2} rotationIntensity={0.15} floatIntensity={0.5}>
      <group position={[0, 0.15, 0]}>
        <group ref={head}>
          <RoundedBox args={[1.7, 1.3, 1.3]} radius={0.38} smoothness={lite ? 3 : 6}>
            <meshStandardMaterial color="#d9dce4" metalness={0.95} roughness={0.16} envMapIntensity={1.5} />
          </RoundedBox>
          {/* glossy face plate */}
          <RoundedBox args={[1.42, 0.95, 0.12]} radius={0.22} smoothness={lite ? 3 : 5} position={[0, 0, 0.64]}>
            <meshStandardMaterial color="#07070b" metalness={0.6} roughness={0.08} envMapIntensity={1.2} />
          </RoundedBox>
          <mesh ref={eyeL} position={[-0.36, 0.12, 0.72]}>
            <capsuleGeometry args={[0.085, 0.16, 6, 12]} />
            <meshBasicMaterial color="#5ce1ff" />
          </mesh>
          <mesh ref={eyeR} position={[0.36, 0.12, 0.72]}>
            <capsuleGeometry args={[0.085, 0.16, 6, 12]} />
            <meshBasicMaterial color="#5ce1ff" />
          </mesh>
          <mesh ref={mouth} position={[0, -0.26, 0.72]}>
            <boxGeometry args={[0.34, 0.08, 0.02]} />
            <meshBasicMaterial color="#7c5cff" />
          </mesh>
          {/* ear pods */}
          <mesh position={[-0.92, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.2, 0.2, 0.14, 24]} />
            <meshStandardMaterial color="#7c5cff" metalness={0.8} roughness={0.25} emissive="#3b2a99" emissiveIntensity={0.7} />
          </mesh>
          <mesh position={[0.92, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.2, 0.2, 0.14, 24]} />
            <meshStandardMaterial color="#7c5cff" metalness={0.8} roughness={0.25} emissive="#3b2a99" emissiveIntensity={0.7} />
          </mesh>
          {/* antenna */}
          <group ref={ant} position={[0, 0.65, 0]}>
            <mesh position={[0, 0.2, 0]}>
              <cylinderGeometry args={[0.035, 0.035, 0.4, 10]} />
              <meshStandardMaterial color="#9aa0ad" metalness={1} roughness={0.2} />
            </mesh>
            <mesh position={[0, 0.48, 0]}>
              <sphereGeometry args={[0.1, 18, 18]} />
              <meshBasicMaterial color="#5ce1ff" />
            </mesh>
          </group>
        </group>

        {/* floating torso + hands */}
        <mesh position={[0, -0.98, 0]}>
          <capsuleGeometry args={[0.38, 0.28, 8, 18]} />
          <meshStandardMaterial color="#c3c7d1" metalness={0.95} roughness={0.2} envMapIntensity={1.4} />
        </mesh>
        <mesh position={[0, -0.92, 0.37]}>
          <circleGeometry args={[0.08, 20]} />
          <meshBasicMaterial color="#7c5cff" />
        </mesh>
        <mesh ref={armL} position={[-0.78, -1.05, 0.05]}>
          <sphereGeometry args={[0.16, 18, 18]} />
          <meshStandardMaterial color="#d9dce4" metalness={0.95} roughness={0.18} />
        </mesh>
        <mesh ref={armR} position={[0.78, -1.05, 0.05]}>
          <sphereGeometry args={[0.16, 18, 18]} />
          <meshStandardMaterial color="#d9dce4" metalness={0.95} roughness={0.18} />
        </mesh>
      </group>
    </Float>
  );
}

export default function RobotScene({ talking = false, lite = true }) {
  return (
    <Canvas
      className="!pointer-events-none"
      dpr={[1, 1.6]}
      camera={{ position: [0, 0, 5.4], fov: 34 }}
      gl={{ antialias: true, alpha: true, powerPreference: "low-power" }}
    >
      <ambientLight intensity={0.5} />
      <pointLight position={[3, 3, 4]} intensity={22} color="#a99bff" />
      <pointLight position={[-3, -1, 3]} intensity={14} color="#5ce1ff" />
      <Environment resolution={64}>
        <Lightformer form="rect" intensity={4} position={[0, 4, 3]} scale={[8, 3, 1]} />
        <Lightformer form="rect" intensity={2} position={[-5, 0, 2]} rotation-y={Math.PI / 2} scale={[6, 3, 1]} />
        <Lightformer form="rect" intensity={2} position={[5, 0, 2]} rotation-y={-Math.PI / 2} scale={[6, 3, 1]} />
      </Environment>
      <Robot talking={talking} lite={lite} />
    </Canvas>
  );
}
