"use client";

import { useEffect, useRef } from "react";
import { registerGsap, prefersReducedMotion } from "@/lib/gsap";
import { useIntroReady } from "@/lib/introGate";

/** Fade/slide up on scroll. With `stagger`, animates direct children one after another. */
export function Reveal({ as: Tag = "div", children, className = "", delay = 0, y = 44, stagger = 0, gate = false, ...rest }) {
  const ref = useRef(null);
  const introReady = useIntroReady();
  const enabled = gate ? introReady : true;

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return;
    const { gsap } = registerGsap();
    const targets = stagger ? Array.from(el.children) : [el];
    if (prefersReducedMotion()) {
      gsap.set(targets, { opacity: 1, y: 0 });
      return;
    }
    const ctx = gsap.context(() => {
      gsap.fromTo(
        targets,
        { opacity: 0, y },
        {
          opacity: 1,
          y: 0,
          duration: 1.05,
          ease: "power3.out",
          delay,
          stagger: stagger || 0,
          scrollTrigger: gate ? undefined : { trigger: el, start: "top 90%", once: true },
          clearProps: "transform",
        }
      );
    }, el);
    return () => ctx.revert();
  }, [enabled, delay, y, stagger, gate]);

  const hiddenProps = stagger ? { "data-reveal-group": "" } : { "data-reveal": "" };
  return (
    <Tag ref={ref} className={`${className} ${stagger ? "reveal-group" : ""}`} {...hiddenProps} {...rest}>
      {children}
    </Tag>
  );
}

/** Splits text into masked words that rise into place. */
export function SplitReveal({ text, as: Tag = "h2", className = "", delay = 0, gate = false, stagger = 0.07, lineBreakAfter = [] }) {
  const ref = useRef(null);
  const introReady = useIntroReady();
  const enabled = gate ? introReady : true;
  const words = text.split(" ");

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return;
    const { gsap } = registerGsap();
    const inners = el.querySelectorAll(".word-inner");
    if (prefersReducedMotion()) {
      gsap.set(inners, { yPercent: 0 });
      el.removeAttribute("data-split-hidden");
      return;
    }
    const ctx = gsap.context(() => {
      gsap.fromTo(
        inners,
        { yPercent: 118, rotate: 4 },
        {
          yPercent: 0,
          rotate: 0,
          duration: 1.1,
          ease: "power4.out",
          stagger,
          delay,
          scrollTrigger: gate ? undefined : { trigger: el, start: "top 88%", once: true },
          onStart: () => el.removeAttribute("data-split-hidden"),
        }
      );
    }, el);
    // Safety net: never leave a heading invisible if the animation never starts.
    const safety = setTimeout(() => el.removeAttribute("data-split-hidden"), 6000);
    return () => {
      clearTimeout(safety);
      ctx.revert();
    };
  }, [enabled, delay, gate, stagger]);

  return (
    <Tag ref={ref} className={className} data-split-hidden="" aria-label={text}>
      {words.map((w, i) => (
        <span key={i} aria-hidden="true">
          <span className="word-mask">
            <span className="word-inner">{w}</span>
          </span>
          {lineBreakAfter.includes(i) ? <br /> : " "}
        </span>
      ))}
    </Tag>
  );
}

/** Scroll-linked vertical drift for decorative layers or images. */
export function Parallax({ children, speed = 12, className = "" }) {
  const wrap = useRef(null);
  const inner = useRef(null);
  useEffect(() => {
    if (prefersReducedMotion() || !wrap.current) return;
    const { gsap } = registerGsap();
    const ctx = gsap.context(() => {
      gsap.fromTo(
        inner.current,
        { yPercent: speed },
        {
          yPercent: -speed,
          ease: "none",
          scrollTrigger: { trigger: wrap.current, start: "top bottom", end: "bottom top", scrub: true },
        }
      );
    }, wrap);
    return () => ctx.revert();
  }, [speed]);
  return (
    <div ref={wrap} className={className}>
      <div ref={inner} className="h-full w-full will-change-transform">
        {children}
      </div>
    </div>
  );
}

/** Image/block reveal: a curtain wipes away to expose the content. */
export function ImageReveal({ children, className = "" }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const { gsap } = registerGsap();
    if (prefersReducedMotion()) {
      gsap.set(el, { clipPath: "inset(0% 0% 0% 0%)", opacity: 1 });
      return;
    }
    const ctx = gsap.context(() => {
      gsap.fromTo(
        el,
        { clipPath: "inset(0% 0% 100% 0%)", opacity: 1 },
        {
          clipPath: "inset(0% 0% 0% 0%)",
          duration: 1.3,
          ease: "power4.inOut",
          scrollTrigger: { trigger: el, start: "top 88%", once: true },
        }
      );
    }, el);
    return () => ctx.revert();
  }, []);
  return (
    <div ref={ref} className={className} data-image-reveal>
      {children}
    </div>
  );
}
