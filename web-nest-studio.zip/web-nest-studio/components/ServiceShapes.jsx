"use client";

import { useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Lightformer, PerformanceMonitor, PerspectiveCamera, RoundedBox, View } from "@react-three/drei";

const metal = { color: "#d7dae2", metalness: 0.95, roughness: 0.16, envMapIntensity: 1.6 };
const glow = (c) => ({ color: c, emissive: c, emissiveIntensity: 0.9, metalness: 0.2, roughness: 0.3 });

function Spin({ children, speed = 0.55, tilt = 0.35 }) {
  const g = useRef();
  useFrame((s, dt) => {
    if (!g.current) return;
    g.current.rotation.y += dt * speed;
    g.current.rotation.x = THREE.MathUtils.damp(g.current.rotation.x, -s.pointer.y * tilt, 4, dt);
    g.current.position.y = Math.sin(s.clock.elapsedTime * 1.4) * 0.06;
  });
  return <group ref={g}>{children}</group>;
}

/* One distinct object per service, in service order. */
const shapes = [
  // 01 Shopify Development: faceted gem with an inner wire core
  () => (
    <Spin>
      <mesh scale={1.05}>
        <octahedronGeometry args={[1, 0]} />
        <meshStandardMaterial {...metal} flatShading />
      </mesh>
      <mesh scale={0.5}>
        <icosahedronGeometry args={[1, 1]} />
        <meshBasicMaterial color="#7c5cff" wireframe />
      </mesh>
    </Spin>
  ),
  // 02 Shopify Full-Stack: stacked layers (front end, logic, data)
  () => (
    <Spin tilt={0.2}>
      <group rotation={[0.45, 0, 0]}>
        {[-0.5, 0, 0.5].map((y, i) => (
          <RoundedBox key={i} args={[1.7, 0.14, 1.7]} radius={0.05} smoothness={3} position={[0, y, 0]}>
            {i === 1 ? <meshStandardMaterial {...glow("#7c5cff")} transparent opacity={0.9} /> : <meshStandardMaterial {...metal} />}
          </RoundedBox>
        ))}
      </group>
    </Spin>
  ),
  // 03 Shopify App: cluster of modules
  () => (
    <Spin>
      <RoundedBox args={[0.95, 0.95, 0.95]} radius={0.12} smoothness={3}>
        <meshStandardMaterial {...metal} />
      </RoundedBox>
      <RoundedBox args={[0.5, 0.5, 0.5]} radius={0.08} smoothness={3} position={[0.8, 0.7, 0.3]}>
        <meshStandardMaterial {...glow("#5ce1ff")} />
      </RoundedBox>
      <RoundedBox args={[0.4, 0.4, 0.4]} radius={0.07} smoothness={3} position={[-0.75, -0.6, -0.2]}>
        <meshStandardMaterial {...metal} />
      </RoundedBox>
    </Spin>
  ),
  // 04 WordPress: flowing knot
  () => (
    <Spin speed={0.4}>
      <mesh>
        <torusKnotGeometry args={[0.62, 0.2, 140, 20, 2, 3]} />
        <meshStandardMaterial {...metal} />
      </mesh>
    </Spin>
  ),
  // 05 Android App: phone with glowing screen
  () => (
    <Spin tilt={0.25}>
      <RoundedBox args={[0.95, 1.7, 0.16]} radius={0.14} smoothness={4}>
        <meshStandardMaterial {...metal} />
      </RoundedBox>
      <mesh position={[0, 0, 0.09]}>
        <planeGeometry args={[0.8, 1.52]} />
        <meshBasicMaterial color="#1a1346" />
      </mesh>
      <mesh position={[0, 0.2, 0.1]}>
        <circleGeometry args={[0.22, 32]} />
        <meshBasicMaterial color="#7c5cff" />
      </mesh>
      <mesh position={[0, -0.35, 0.1]}>
        <planeGeometry args={[0.5, 0.08]} />
        <meshBasicMaterial color="#5ce1ff" />
      </mesh>
    </Spin>
  ),
  // 06 Website Designing: pen nib
  () => (
    <Spin>
      <group rotation={[0, 0, 0.6]}>
        <mesh position={[0, -0.55, 0]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[0.28, 0.9, 32]} />
          <meshStandardMaterial {...metal} />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <capsuleGeometry args={[0.28, 0.8, 8, 24]} />
          <meshStandardMaterial {...metal} />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <torusGeometry args={[0.3, 0.035, 12, 48]} />
          <meshStandardMaterial {...glow("#5ce1ff")} />
        </mesh>
      </group>
    </Spin>
  ),
  // 07 Website Redesigning: two interlocking rings
  () => (
    <Spin speed={0.5}>
      <mesh>
        <torusGeometry args={[0.72, 0.16, 24, 72]} />
        <meshStandardMaterial {...metal} />
      </mesh>
      <mesh rotation={[0, Math.PI / 2, 0]} position={[0.45, 0, 0]}>
        <torusGeometry args={[0.72, 0.16, 24, 72]} />
        <meshStandardMaterial {...glow("#7c5cff")} />
      </mesh>
    </Spin>
  ),
  // 08 Maintenance: gear
  () => (
    <Spin speed={0.7} tilt={0.15}>
      <mesh>
        <torusGeometry args={[0.62, 0.24, 20, 48]} />
        <meshStandardMaterial {...metal} />
      </mesh>
      {Array.from({ length: 8 }, (_, i) => {
        const a = (i / 8) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.98, Math.sin(a) * 0.98, 0]} rotation={[0, 0, a]}>
            <boxGeometry args={[0.28, 0.24, 0.4]} />
            <meshStandardMaterial {...metal} />
          </mesh>
        );
      })}
    </Spin>
  ),
];

export function ServiceView({ index, className = "" }) {
  const Shape = shapes[index % shapes.length];
  return (
    <View className={className}>
      <PerspectiveCamera makeDefault position={[0, 0, 4.4]} fov={34} />
      <ambientLight intensity={0.5} />
      <pointLight position={[3, 3, 4]} intensity={24} color="#a99bff" />
      <pointLight position={[-3, -1, 3]} intensity={16} color="#5ce1ff" />
      <Environment frames={1} resolution={64}>
        <Lightformer form="rect" intensity={4} position={[0, 4, 3]} scale={[8, 3, 1]} />
        <Lightformer form="rect" intensity={2} position={[-5, 0, 2]} rotation-y={Math.PI / 2} scale={[6, 3, 1]} />
        <Lightformer form="rect" intensity={2} position={[5, 0, 2]} rotation-y={-Math.PI / 2} scale={[6, 3, 1]} />
      </Environment>
      <Shape />
    </View>
  );
}

/** The single shared canvas that draws every ServiceView. */
export function ServiceCanvas({ active, onDegrade }) {
  return (
    <Canvas
      frameloop={active ? "always" : "never"}
      eventSource={document.body}
      eventPrefix="client"
      dpr={[1, 1.5]}
      gl={{ alpha: true, antialias: true }}
      style={{ position: "fixed", inset: 0, pointerEvents: "none" }}
    >
      {/* Sustained < ~18 fps: give up on 3D and let the cards fall back to icons. */}
      <PerformanceMonitor bounds={() => [18, 60]} iterations={8} onDecline={onDegrade} />
      <View.Port />
    </Canvas>
  );
}
