"use client";

import Link from "next/link";
import { ArrowRight, ChevronDown } from "lucide-react";
import HeroVisual from "./HeroVisual";
import { Reveal, SplitReveal } from "./Reveal";

const roles = ["Full Stack Web Developer", "Shopify Developer", "Available for Freelance Projects"];

export default function Hero() {
  return (
    <section
      id="home"
      aria-labelledby="hero-title"
      className="relative isolate flex min-h-[100svh] items-end overflow-hidden pb-20 pt-28 md:items-center md:pb-0"
    >
      <div
        className="absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(60% 50% at 75% 40%, rgba(124,92,255,.16), transparent 70%), radial-gradient(40% 40% at 15% 85%, rgba(92,225,255,.07), transparent 70%), #050506",
        }}
      />
      <HeroVisual />
      {/* readability scrims */}
      <div className="pointer-events-none absolute inset-0 z-[1] bg-gradient-to-t from-ink via-ink/55 to-transparent md:bg-gradient-to-r md:from-ink md:via-ink/50 md:to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-[1] h-40 bg-gradient-to-t from-ink to-transparent" />

      <div className="relative z-10 mx-auto w-full max-w-6xl px-5 sm:px-8">
        <Reveal gate className="mb-6 flex flex-wrap gap-2" y={20}>
          {roles.map((r, i) => (
            <span
              key={r}
              className={`glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] text-silver sm:text-xs`}
            >
              {i === 2 && (
                <span className="relative flex h-2 w-2" aria-hidden="true">
                  <span className="absolute h-full w-full animate-pulseDot rounded-full bg-emerald-400" />
                  <span className="relative h-2 w-2 rounded-full bg-emerald-400" />
                </span>
              )}
              {r}
            </span>
          ))}
        </Reveal>

        <SplitReveal
          gate
          as="h1"
          text="Building Digital Experiences That Make Brands Unforgettable."
          className="h-display max-w-4xl text-[clamp(2.5rem,8.4vw,6.4rem)] text-white"
          lineBreakAfter={[2]}
        />
        <span id="hero-title" className="sr-only">
          Building Digital Experiences That Make Brands Unforgettable.
        </span>

        <Reveal gate delay={0.5} className="mt-7 max-w-xl text-base leading-relaxed text-silver/90 sm:text-lg">
          <p>
            I design and develop high-performance digital experiences, eCommerce platforms and custom web applications.
          </p>
        </Reveal>

        <Reveal gate delay={0.7} className="mt-9 flex flex-col gap-3 sm:flex-row" y={24}>
          <Link href="/work" className="btn btn-primary" data-cursor="Work">
            Explore My Work <ArrowRight size={17} aria-hidden="true" />
          </Link>
          <Link href="/contact" className="btn btn-ghost">
            Let&apos;s Work Together
          </Link>
        </Reveal>
      </div>

      <a
        href="#work"
        aria-label="Scroll to work"
        className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-mist transition hover:text-white md:flex"
      >
        Scroll
        <ChevronDown size={16} className="animate-bounce" aria-hidden="true" />
      </a>
    </section>
  );
}
