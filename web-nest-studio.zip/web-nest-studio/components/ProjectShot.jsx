import Image from "next/image";

/**
 * Renders a real screenshot when one exists in /public/projects/<slug>/.
 * Otherwise renders a clearly labelled placeholder - never unrelated imagery.
 */
export default function ProjectShot({ src, project, kind = "desktop", priority = false, sizes = "(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw", className = "", label }) {
  if (src) {
    return (
      <Image
        src={src}
        alt={`${project.name} website - ${kind === "mobile" ? "mobile" : "desktop"} view${label ? `, ${label}` : ""}`}
        fill
        sizes={sizes}
        priority={priority}
        className={`object-cover object-top ${className}`}
      />
    );
  }

  const mobile = kind === "mobile";
  return (
    <div
      role="img"
      aria-label={`Screenshot of ${project.name} pending`}
      className={`absolute inset-0 flex items-center justify-center overflow-hidden bg-graphite ${className}`}
      style={{ backgroundImage: `radial-gradient(70% 60% at 50% 30%, ${project.accent}22, transparent 70%)` }}
    >
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)",
          backgroundSize: "36px 36px",
        }}
      />
      <div className={`relative flex flex-col ${mobile ? "h-[78%] w-[62%]" : "h-[74%] w-[80%]"} overflow-hidden rounded-xl border border-white/15 bg-ink/80`}>
        {!mobile && (
          <div className="flex items-center gap-1.5 border-b border-white/10 px-3 py-2">
            <span className="h-2 w-2 rounded-full bg-white/25" />
            <span className="h-2 w-2 rounded-full bg-white/20" />
            <span className="h-2 w-2 rounded-full bg-white/15" />
            <span className="ml-3 truncate rounded-full bg-white/8 px-3 py-0.5 font-mono text-[10px] text-mist">{project.host}</span>
          </div>
        )}
        <div className="flex flex-1 flex-col justify-center gap-2.5 p-4">
          <span className="h-2 w-1/3 rounded-full" style={{ background: project.accent, opacity: 0.7 }} />
          <span className="h-2 w-4/5 rounded-full bg-white/12" />
          <span className="h-2 w-3/5 rounded-full bg-white/10" />
          <span className="mt-2 h-14 rounded-lg bg-white/[0.06]" />
        </div>
        <div className="border-t border-white/10 px-3 py-2 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-mist">
          Screenshot pending
        </div>
      </div>
    </div>
  );
}
