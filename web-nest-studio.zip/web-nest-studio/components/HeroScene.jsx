"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Float, Lightformer, Points, PointMaterial } from "@react-three/drei";
import { useIntroReady } from "@/lib/introGate";

function Sculpture({ lite }) {
  const group = useRef();
  const knot = useRef();
  const ring1 = useRef();
  const ring2 = useRef();
  const core = useRef();
  const grow = useRef(0.001);
  const ready = useIntroReady();
  const size = useThree((s) => s.size);
  const desktop = size.width >= 900;

  useFrame((state, dt) => {
    const g = group.current;
    if (!g) return;
    const scroll = Math.min(window.scrollY / Math.max(window.innerHeight, 1), 1.4);
    const p = state.pointer;
    grow.current = THREE.MathUtils.damp(grow.current, ready ? 1 : 0.001, 1.8, dt);
    const base = desktop ? 0.85 : 0.78;
    g.scale.setScalar(grow.current * base * (1 - Math.min(scroll, 1) * 0.3));
    g.position.x = THREE.MathUtils.damp(g.position.x, desktop ? 2.75 - scroll * 1.4 : 0, 3, dt);
    g.position.y = THREE.MathUtils.damp(g.position.y, (desktop ? 0 : 1.35) + scroll * 1.4, 3, dt);
    g.rotation.y = THREE.MathUtils.damp(g.rotation.y, p.x * 0.55 + scroll * 1.8, 3, dt);
    g.rotation.x = THREE.MathUtils.damp(g.rotation.x, -p.y * 0.32 + scroll * 0.5, 3, dt);
    if (knot.current) {
      knot.current.rotation.z += dt * 0.16;
      knot.current.rotation.x += dt * 0.09;
    }
    if (ring1.current) ring1.current.rotation.x += dt * 0.32;
    if (ring2.current) ring2.current.rotation.y -= dt * 0.26;
    if (core.current) {
      core.current.rotation.y += dt * 0.5;
      core.current.rotation.x -= dt * 0.3;
    }
  });

  return (
    <group ref={group} scale={0.001}>
      <mesh ref={knot}>
        <torusKnotGeometry args={[1.05, 0.33, lite ? 150 : 260, lite ? 22 : 36, 2, 3]} />
        <meshStandardMaterial color="#d7dae2" metalness={1} roughness={0.14} envMapIntensity={1.7} />
      </mesh>

      <mesh ref={core}>
        <icosahedronGeometry args={[0.52, 1]} />
        <meshBasicMaterial color="#7c5cff" wireframe transparent opacity={0.9} />
      </mesh>

      <mesh ref={ring1} rotation={[1.1, 0.2, 0]}>
        <torusGeometry args={[1.95, 0.011, 12, 180]} />
        <meshBasicMaterial color="#c9ccd3" transparent opacity={0.65} />
      </mesh>
      <mesh ref={ring2} rotation={[0.3, 0.6, 1.2]}>
        <torusGeometry args={[2.35, 0.008, 12, 200]} />
        <meshBasicMaterial color="#5ce1ff" transparent opacity={0.45} />
      </mesh>

      {[
        { p: [-2.2, 1.35, 0.4], s: 0.34, g: "octa" },
        { p: [1.9, -1.55, 0.7], s: 0.28, g: "tetra" },
        { p: [0.5, 2.1, -0.8], s: 0.22, g: "octa" },
        { p: [-1.5, -1.8, -0.4], s: 0.24, g: "box" },
      ].map((o, i) => (
        <Float key={i} speed={1.4 + i * 0.3} rotationIntensity={1.6} floatIntensity={1.2}>
          <mesh position={o.p} scale={o.s}>
            {o.g === "octa" ? <octahedronGeometry args={[1, 0]} /> : o.g === "tetra" ? <tetrahedronGeometry args={[1.2, 0]} /> : <boxGeometry args={[1.4, 1.4, 1.4]} />}
            {lite ? (
              <meshStandardMaterial color="#aeb4c4" metalness={0.9} roughness={0.2} transparent opacity={0.85} />
            ) : (
              <meshPhysicalMaterial color="#ffffff" transmission={1} thickness={0.9} roughness={0.04} ior={1.45} envMapIntensity={1.4} />
            )}
          </mesh>
        </Float>
      ))}
    </group>
  );
}

function Particles({ count }) {
  const ref = useRef();
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 3.5 + Math.random() * 7;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = r * Math.sin(ph) * Math.cos(th);
      arr[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th) * 0.7;
      arr[i * 3 + 2] = r * Math.cos(ph) - 2;
    }
    return arr;
  }, [count]);
  useFrame((_, dt) => {
    if (ref.current) {
      ref.current.rotation.y += dt * 0.012;
      ref.current.rotation.x += dt * 0.004;
    }
  });
  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial transparent color="#cfd3df" size={0.028} sizeAttenuation depthWrite={false} opacity={0.7} />
    </Points>
  );
}

export default function HeroScene({ active = true, lite = false }) {
  return (
    <Canvas
      className="!pointer-events-none"
      frameloop={active ? "always" : "never"}
      dpr={[1, lite ? 1.3 : 1.8]}
      camera={{ position: [0, 0, 7.2], fov: 38 }}
      gl={{ antialias: !lite, alpha: true, powerPreference: "high-performance" }}
      eventSource={typeof document !== "undefined" ? document.body : undefined}
      eventPrefix="client"
    >
      <ambientLight intensity={0.35} />
      <pointLight position={[4, 3, 4]} intensity={40} color="#7c5cff" />
      <pointLight position={[-5, -2, 3]} intensity={32} color="#5ce1ff" />
      <Environment resolution={lite ? 128 : 256}>
        <Lightformer form="rect" intensity={5} position={[0, 5, -4]} scale={[14, 4, 1]} />
        <Lightformer form="rect" intensity={3} position={[-6, 0, 2]} rotation-y={Math.PI / 2} scale={[8, 3, 1]} />
        <Lightformer form="rect" intensity={3} position={[6, 1, 2]} rotation-y={-Math.PI / 2} scale={[8, 3, 1]} />
        <Lightformer form="ring" intensity={4} color="#a99bff" position={[0, -2, 5]} scale={4} />
      </Environment>
      <Sculpture lite={lite} />
      <Particles count={lite ? 260 : 700} />
    </Canvas>
  );
}
