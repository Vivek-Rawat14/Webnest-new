"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Pause, Play, Volume1, Volume2, VolumeX } from "lucide-react";

const KEY = "wns-audio";
const TARGET_DEFAULT = 0.35;

/** Opt-in ambient music. Never autoplays; remembers the visitor's choice across pages. */
export default function MusicPlayer() {
  const audio = useRef(null);
  const fade = useRef(0);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(TARGET_DEFAULT);
  const [pending, setPending] = useState(false); // saved "on" but waiting for a gesture
  const [failed, setFailed] = useState(false);
  const [open, setOpen] = useState(false);
  const volRef = useRef(TARGET_DEFAULT);

  const save = useCallback((on, vol) => {
    try {
      localStorage.setItem(KEY, JSON.stringify({ on, vol }));
    } catch {}
  }, []);

  const ensureAudio = useCallback(() => {
    if (!audio.current) {
      const a = new Audio("/audio/ambient.mp3");
      a.loop = true;
      a.preload = "none";
      a.volume = 0;
      a.addEventListener("error", () => {
        setFailed(true);
        setPlaying(false);
      });
      audio.current = a;
    }
    return audio.current;
  }, []);

  const rampTo = useCallback((to, ms = 900, done) => {
    const a = audio.current;
    if (!a) return;
    cancelAnimationFrame(fade.current);
    const from = a.volume;
    const t0 = performance.now();
    const step = (now) => {
      const k = Math.min((now - t0) / ms, 1);
      a.volume = Math.max(0, Math.min(1, from + (to - from) * k));
      if (k < 1) fade.current = requestAnimationFrame(step);
      else done?.();
    };
    fade.current = requestAnimationFrame(step);
  }, []);

  const play = useCallback(async () => {
    const a = ensureAudio();
    try {
      await a.play();
      setPlaying(true);
      setPending(false);
      setFailed(false);
      rampTo(volRef.current);
      save(true, volRef.current);
      return true;
    } catch (e) {
      if (e && e.name === "NotAllowedError") setPending(true);
      else setFailed(true);
      return false;
    }
  }, [ensureAudio, rampTo, save]);

  const pause = useCallback(() => {
    setPlaying(false);
    setPending(false);
    save(false, volRef.current);
    rampTo(0, 500, () => audio.current?.pause());
  }, [rampTo, save]);

  // Restore preference. Browsers block sound without a gesture, so wait for the first one.
  useEffect(() => {
    let saved = null;
    try {
      saved = JSON.parse(localStorage.getItem(KEY) || "null");
    } catch {}
    if (saved?.vol != null) {
      setVolume(saved.vol);
      volRef.current = saved.vol;
    }
    if (!saved?.on) return;
    setPending(true);
    const resume = () => {
      cleanup();
      play();
    };
    const cleanup = () => {
      window.removeEventListener("pointerdown", resume);
      window.removeEventListener("keydown", resume);
    };
    window.addEventListener("pointerdown", resume, { once: true });
    window.addEventListener("keydown", resume, { once: true });
    return cleanup;
  }, [play]);

  // Be polite: pause when the tab is hidden, resume when it returns.
  useEffect(() => {
    let wasPlaying = false;
    const onVis = () => {
      const a = audio.current;
      if (!a) return;
      if (document.hidden) {
        wasPlaying = !a.paused;
        if (wasPlaying) a.pause();
      } else if (wasPlaying) {
        a.play().catch(() => {});
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      cancelAnimationFrame(fade.current);
      audio.current?.pause();
    };
  }, []);

  const onVolume = (e) => {
    const v = Number(e.target.value);
    setVolume(v);
    volRef.current = v;
    if (audio.current && playing) {
      cancelAnimationFrame(fade.current);
      audio.current.volume = v;
    }
    save(playing, v);
  };

  const VolIcon = volume === 0 ? VolumeX : volume < 0.4 ? Volume1 : Volume2;
  const label = playing ? "Pause ambient music" : "Play ambient music";

  return (
    <div
      className="glass fixed bottom-4 left-3 z-40 flex items-center gap-1 rounded-full p-1.5 sm:bottom-6 sm:left-6"
      role="group"
      aria-label="Ambient music"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        type="button"
        onClick={() => (playing ? pause() : play())}
        aria-label={label}
        aria-pressed={playing}
        className="grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
      >
        {playing ? <Pause size={16} aria-hidden="true" /> : <Play size={16} className="translate-x-px" aria-hidden="true" />}
      </button>

      <div className="flex h-11 items-center gap-[3px] px-2" aria-hidden="true">
        {[0, 0.2, 0.4, 0.1, 0.3].map((d, i) => (
          <span
            key={i}
            className={`h-4 w-[3px] origin-center rounded-full bg-silver ${playing ? "animate-eq" : ""}`}
            style={{ animationDelay: `${d}s`, transform: playing ? undefined : "scaleY(.25)", opacity: playing ? 1 : 0.5 }}
          />
        ))}
      </div>

      <div
        className={`flex items-center gap-2 overflow-hidden transition-all duration-500 ${
          open ? "max-w-[150px] pr-3 opacity-100" : "max-w-0 opacity-0 focus-within:max-w-[150px] focus-within:pr-3 focus-within:opacity-100"
        }`}
      >
        <VolIcon size={15} className="shrink-0 text-mist" aria-hidden="true" />
        <input
          type="range"
          min="0"
          max="1"
          step="0.02"
          value={volume}
          onChange={onVolume}
          aria-label="Music volume"
          className="h-1 w-20 accent-white"
        />
      </div>

      <span className="sr-only" role="status">
        {failed ? "Music could not be loaded" : playing ? "Music playing" : "Music off"}
      </span>
      {(pending || failed) && !playing && (
        <span className="hidden pr-3 text-[11px] text-mist sm:inline">{failed ? "Audio unavailable" : "Tap to resume"}</span>
      )}
      {!pending && !failed && !playing && <span className="hidden pr-3 text-[11px] text-mist sm:inline">Ambient sound</span>}
    </div>
  );
}
