"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Html, Lightformer } from "@react-three/drei";
import { skills } from "@/lib/data";
import { look } from "@/lib/webgl";

const R = 2.35;

function fibonacci(n) {
  const pts = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < n; i++) {
    const y = 1 - (i / (n - 1)) * 2;
    const r = Math.sqrt(1 - y * y);
    const t = golden * i;
    pts.push(new THREE.Vector3(Math.cos(t) * r, y, Math.sin(t) * r).multiplyScalar(R));
  }
  return pts;
}

function Node({ position, name, group }) {
  const label = useRef();
  const dot = useRef();
  const tmp = useMemo(() => new THREE.Vector3(), []);
  useFrame(() => {
    if (!dot.current || !label.current) return;
    dot.current.getWorldPosition(tmp);
    // Front-facing nodes are bright, back-facing ones fade into the sphere.
    const k = THREE.MathUtils.clamp((tmp.z + R) / (2 * R), 0, 1);
    label.current.style.opacity = String(0.18 + k * 0.82);
    label.current.style.transform = `scale(${0.78 + k * 0.3})`;
  });
  return (
    <group position={position}>
      <mesh ref={dot}>
        <sphereGeometry args={[0.055, 12, 12]} />
        <meshBasicMaterial color="#5ce1ff" />
      </mesh>
      <Html center zIndexRange={[10, 0]} style={{ pointerEvents: "none" }}>
        <span
          ref={label}
          className="inline-block translate-y-5 whitespace-nowrap rounded-full border border-white/20 bg-ink/70 px-3 py-1 text-xs font-semibold text-white backdrop-blur-sm transition-none sm:text-sm"
        >
          {name}
        </span>
      </Html>
    </group>
  );
}

function Globe() {
  const group = useRef();
  const core = useRef();
  const points = useMemo(() => fibonacci(skills.length), []);

  useFrame((s, dt) => {
    const g = group.current;
    if (!g) return;
    g.rotation.y += dt * 0.22;
    g.rotation.x = THREE.MathUtils.damp(g.rotation.x, -look.y * 0.35, 3, dt);
    g.rotation.y += look.x * dt * 0.25;
    if (core.current) {
      core.current.rotation.y -= dt * 0.4;
      core.current.rotation.x += dt * 0.25;
    }
  });

  return (
    <group ref={group}>
      <mesh>
        <icosahedronGeometry args={[R * 0.985, 2]} />
        <meshBasicMaterial color="#7c5cff" wireframe transparent opacity={0.16} />
      </mesh>
      <mesh ref={core}>
        <icosahedronGeometry args={[0.85, 1]} />
        <meshStandardMaterial color="#d7dae2" metalness={1} roughness={0.14} envMapIntensity={1.7} flatShading />
      </mesh>
      <mesh rotation={[1.2, 0.3, 0]}>
        <torusGeometry args={[R * 1.12, 0.008, 8, 160]} />
        <meshBasicMaterial color="#5ce1ff" transparent opacity={0.5} />
      </mesh>
      {points.map((p, i) => (
        <Node key={skills[i].name} position={p} name={skills[i].name} />
      ))}
    </group>
  );
}

export default function SkillsSphere({ active = true, lite = false }) {
  return (
    <Canvas
      className="!pointer-events-none"
      frameloop={active ? "always" : "never"}
      dpr={[1, lite ? 1.3 : 1.8]}
      camera={{ position: [0, 0, 8.2], fov: 38 }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.45} />
      <pointLight position={[4, 3, 5]} intensity={40} color="#a99bff" />
      <pointLight position={[-4, -2, 4]} intensity={26} color="#5ce1ff" />
      <Environment frames={1} resolution={64}>
        <Lightformer form="rect" intensity={4} position={[0, 5, 3]} scale={[10, 3, 1]} />
        <Lightformer form="rect" intensity={2} position={[-6, 0, 2]} rotation-y={Math.PI / 2} scale={[8, 3, 1]} />
        <Lightformer form="rect" intensity={2} position={[6, 0, 2]} rotation-y={-Math.PI / 2} scale={[8, 3, 1]} />
      </Environment>
      <Globe />
    </Canvas>
  );
}
