"use client";

import Link from "next/link";
import { useRef } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import ProjectShot from "./ProjectShot";

export default function ProjectCard({ project, priority = false }) {
  const box = useRef(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const x = useSpring(mx, { stiffness: 120, damping: 18 });
  const y = useSpring(my, { stiffness: 120, damping: 18 });

  const onMove = (e) => {
    const r = box.current?.getBoundingClientRect();
    if (!r) return;
    mx.set(-((e.clientX - r.left) / r.width - 0.5) * 22);
    my.set(-((e.clientY - r.top) / r.height - 0.5) * 14);
  };
  const onLeave = () => {
    mx.set(0);
    my.set(0);
  };

  return (
    <article className="group panel relative flex flex-col overflow-hidden rounded-3xl transition-colors duration-500 hover:border-white/25">
      <Link
        href={`/work/${project.slug}`}
        aria-label={`View ${project.name} case study`}
        data-cursor="View"
        className="relative block overflow-hidden"
        onMouseMove={onMove}
        onMouseLeave={onLeave}
      >
        <div ref={box} className="relative aspect-[4/3] overflow-hidden bg-graphite">
          <motion.div className="absolute -inset-4" style={{ x, y }}>
            <div className="absolute inset-0 transition-transform duration-[900ms] ease-[cubic-bezier(.2,.8,.2,1)] group-hover:scale-[1.07]">
              <ProjectShot src={project.shots.desktop[0]} project={project} priority={priority} />
            </div>
          </motion.div>

          {/* number: rolls on hover */}
          <div className="absolute left-4 top-4 h-8 overflow-hidden rounded-full bg-ink/70 px-3 font-mono text-xs text-white backdrop-blur-md">
            <div className="transition-transform duration-500 ease-out group-hover:-translate-y-8">
              <span className="flex h-8 items-center">{project.number}</span>
              <span className="flex h-8 items-center gap-1" style={{ color: project.accent }}>
                {project.number} <ArrowUpRight size={12} aria-hidden="true" />
              </span>
            </div>
          </div>

          {/* hover reveal - kept light so the work stays visible */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 flex translate-y-full items-end bg-gradient-to-t from-ink/85 via-ink/30 to-transparent p-5 pt-16 transition-transform duration-500 ease-out group-hover:translate-y-0">
            <span className="inline-flex items-center gap-2 text-sm font-semibold text-white">
              Open case study <ArrowRight size={16} aria-hidden="true" />
            </span>
          </div>
        </div>
      </Link>

      <div className="flex flex-1 flex-col p-6">
        <p className="eyebrow">{project.type}</p>
        <h3 className="h-display mt-2 text-2xl text-white">{project.name}</h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-mist">{project.short}</p>

        <ul className="mt-5 flex flex-wrap gap-2" aria-label="Technologies">
          {project.tech.map((t) => (
            <li key={t} className="rounded-full border border-white/12 bg-white/[0.04] px-3 py-1 text-[11px] text-silver">
              {t}
            </li>
          ))}
        </ul>

        <div className="mt-6 flex items-center gap-3">
          <Link href={`/work/${project.slug}`} className="btn btn-primary !min-h-[44px] flex-1 !px-4 !py-2.5 text-sm">
            View Case Study
          </Link>
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Visit ${project.name} live website (opens in a new tab)`}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-white/20 text-white transition hover:border-white/60 hover:bg-white/10"
          >
            <ArrowUpRight size={18} aria-hidden="true" />
          </a>
        </div>
      </div>
    </article>
  );
}
