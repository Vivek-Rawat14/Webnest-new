"use client";

import Link from "next/link";
import { ArrowUpRight, RotateCcw } from "lucide-react";
import Logo from "./Logo";
import { navLinks, site } from "@/lib/site";
import { REPLAY_EVENT } from "@/lib/introGate";

export default function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-coal/60">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo variant="full" size={44} />
          <p className="mt-6 max-w-xs text-sm leading-relaxed text-mist">{site.tagline}</p>
          <button
            type="button"
            onClick={() => window.dispatchEvent(new Event(REPLAY_EVENT))}
            className="mt-6 inline-flex min-h-[44px] items-center gap-2 text-xs text-mist transition hover:text-white"
          >
            <RotateCcw size={14} aria-hidden="true" /> Replay intro
          </button>
        </div>

        <nav aria-label="Footer">
          <p className="eyebrow mb-5">Navigate</p>
          <ul className="space-y-1">
            {[...navLinks, { label: "Skills", href: "/skills" }].map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="inline-block py-1.5 text-sm text-silver transition hover:text-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="eyebrow mb-5">Connect</p>
          <ul className="space-y-1">
            <li>
              <a href={`mailto:${site.email}`} className="inline-block py-1.5 text-sm text-silver transition hover:text-white">
                {site.email}
              </a>
            </li>
            {site.socials.map((s) => (
              <li key={s.label}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 py-1.5 text-sm text-silver transition hover:text-white"
                >
                  {s.label} <ArrowUpRight size={13} aria-hidden="true" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="hairline" />
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-6 text-xs text-mist sm:flex-row sm:justify-between sm:px-8">
        <p>&copy; {new Date().getFullYear()} {site.name}. All rights reserved.</p>
        <p>Designed and built by Web Nest Studio.</p>
      </div>
    </footer>
  );
}
