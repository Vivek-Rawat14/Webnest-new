"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, Lightformer, Points, PointMaterial } from "@react-three/drei";
import { look } from "@/lib/webgl";

// The Web Nest Studio mark, rebuilt in 3D from the same coordinates as the SVG logo.
const S = 0.075;
const to3 = ([x, y], z) => new THREE.Vector3((x - 32) * S, (32 - y) * S, z);
const layers = [
  { pts: [[5, 10], [19, 54], [32, 24], [45, 54], [59, 10]], r: 0.1, z: 0 },
  { pts: [[14, 20], [24, 50], [32, 34], [40, 50], [50, 20]], r: 0.08, z: -0.38 },
  { pts: [[23, 29], [28, 46], [32, 40], [36, 46], [41, 29]], r: 0.06, z: -0.72 },
];
const UP = new THREE.Vector3(0, 1, 0);

function Beam({ a, b, r }) {
  const { pos, quat, len } = useMemo(() => {
    const dir = new THREE.Vector3().subVectors(b, a);
    return {
      len: dir.length(),
      pos: new THREE.Vector3().addVectors(a, b).multiplyScalar(0.5),
      quat: new THREE.Quaternion().setFromUnitVectors(UP, dir.clone().normalize()),
    };
  }, [a, b]);
  return (
    <mesh position={pos} quaternion={quat}>
      <cylinderGeometry args={[r, r, len, 20]} />
      <meshStandardMaterial color="#e1e4eb" metalness={1} roughness={0.13} envMapIntensity={1.8} />
    </mesh>
  );
}

function Mark() {
  const group = useRef();
  const orbit = useRef();
  const segs = useMemo(
    () =>
      layers.map((L) => {
        const v = L.pts.map((p) => to3(p, L.z));
        return { r: L.r, v, pairs: v.slice(1).map((p, i) => [v[i], p]) };
      }),
    []
  );

  useFrame((s, dt) => {
    const g = group.current;
    if (!g) return;
    g.rotation.y = THREE.MathUtils.damp(g.rotation.y, look.x * 0.7 + Math.sin(s.clock.elapsedTime * 0.5) * 0.25, 3, dt);
    g.rotation.x = THREE.MathUtils.damp(g.rotation.x, -look.y * 0.3, 3, dt);
    if (orbit.current) {
      orbit.current.rotation.z += dt * 0.35;
      orbit.current.rotation.y += dt * 0.18;
    }
  });

  return (
    <Float speed={1.6} rotationIntensity={0.1} floatIntensity={0.6}>
      <group ref={group} position={[0, -0.1, 0.3]}>
        {segs.map((L, li) => (
          <group key={li}>
            {L.pairs.map(([a, b], i) => (
              <Beam key={i} a={a} b={b} r={L.r} />
            ))}
            {L.v.map((p, i) => (
              <mesh key={i} position={p}>
                <sphereGeometry args={[L.r, 20, 20]} />
                <meshStandardMaterial color="#e1e4eb" metalness={1} roughness={0.13} envMapIntensity={1.8} />
              </mesh>
            ))}
          </group>
        ))}
        {/* the node: the idea at the top of the nest */}
        <mesh position={to3([32, 12], 0)}>
          <sphereGeometry args={[0.17, 24, 24]} />
          <meshStandardMaterial color="#7c5cff" emissive="#7c5cff" emissiveIntensity={1.2} />
        </mesh>
        <group ref={orbit} position={[0, 0, -0.35]}>
          <mesh rotation={[1.15, 0, 0]}>
            <torusGeometry args={[2.9, 0.012, 8, 160]} />
            <meshBasicMaterial color="#5ce1ff" transparent opacity={0.55} />
          </mesh>
          <mesh rotation={[0.3, 0.8, 0.4]}>
            <torusGeometry args={[3.35, 0.009, 8, 180]} />
            <meshBasicMaterial color="#c9ccd3" transparent opacity={0.35} />
          </mesh>
        </group>
      </group>
    </Float>
  );
}

function Dust() {
  const pos = useMemo(() => {
    const a = new Float32Array(240 * 3);
    for (let i = 0; i < 240; i++) {
      const r = 3 + Math.random() * 4;
      const t = Math.random() * Math.PI * 2;
      const p = Math.acos(2 * Math.random() - 1);
      a[i * 3] = r * Math.sin(p) * Math.cos(t);
      a[i * 3 + 1] = r * Math.sin(p) * Math.sin(t);
      a[i * 3 + 2] = r * Math.cos(p) - 2;
    }
    return a;
  }, []);
  return (
    <Points positions={pos} stride={3} frustumCulled={false}>
      <PointMaterial transparent color="#cfd3df" size={0.03} sizeAttenuation depthWrite={false} opacity={0.6} />
    </Points>
  );
}

export default function LogoScene({ active = true, lite = false }) {
  return (
    <Canvas
      className="!pointer-events-none"
      frameloop={active ? "always" : "never"}
      dpr={[1, lite ? 1.3 : 1.8]}
      camera={{ position: [0, 0, 9.6], fov: 36 }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.4} />
      <pointLight position={[4, 3, 5]} intensity={36} color="#a99bff" />
      <pointLight position={[-4, -2, 4]} intensity={24} color="#5ce1ff" />
      <Environment frames={1} resolution={128}>
        <Lightformer form="rect" intensity={5} position={[0, 5, 3]} scale={[12, 3, 1]} />
        <Lightformer form="rect" intensity={3} position={[-6, 0, 2]} rotation-y={Math.PI / 2} scale={[8, 4, 1]} />
        <Lightformer form="rect" intensity={3} position={[6, 0, 2]} rotation-y={-Math.PI / 2} scale={[8, 4, 1]} />
        <Lightformer form="ring" intensity={4} color="#a99bff" position={[0, -2, 5]} scale={4} />
      </Environment>
      <Mark />
      <Dust />
    </Canvas>
  );
}
