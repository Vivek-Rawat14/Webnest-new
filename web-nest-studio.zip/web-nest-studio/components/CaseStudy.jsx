"use client";

import Link from "next/link";
import { ArrowRight, ArrowUpRight, Check } from "lucide-react";
import ProjectShot from "./ProjectShot";
import { ImageReveal, Parallax, Reveal, SplitReveal } from "./Reveal";

const wrap = "mx-auto max-w-6xl px-5 sm:px-8";

function Browser({ project, src, className = "", aspect = "aspect-[16/10]", priority = false, sizes = "(min-width:1152px) 1152px, 100vw", label }) {
  return (
    <div className={`overflow-hidden rounded-2xl border border-white/15 bg-coal shadow-[0_40px_90px_-30px_rgba(0,0,0,.9)] ${className}`}>
      <div className="flex items-center gap-2 border-b border-white/10 bg-graphite px-4 py-2.5">
        <span className="flex gap-1.5" aria-hidden="true">
          <i className="h-2.5 w-2.5 rounded-full bg-white/25" />
          <i className="h-2.5 w-2.5 rounded-full bg-white/18" />
          <i className="h-2.5 w-2.5 rounded-full bg-white/12" />
        </span>
        <span className="mx-auto max-w-[60%] truncate rounded-full bg-white/[0.06] px-4 py-1 font-mono text-[11px] text-mist">{project.host}</span>
        <span className="w-10" aria-hidden="true" />
      </div>
      <div className={`relative ${aspect} overflow-hidden bg-graphite`}>
        <ProjectShot src={src} project={project} priority={priority} sizes={sizes} label={label} />
      </div>
    </div>
  );
}

function Phone({ project, src, label }) {
  return (
    <div className="mx-auto w-[min(260px,72vw)] shrink-0 rounded-[2.4rem] border border-white/20 bg-ink p-2.5 shadow-[0_40px_80px_-30px_rgba(0,0,0,.9)]">
      <div className="relative aspect-[9/19] overflow-hidden rounded-[1.9rem] bg-graphite">
        <ProjectShot src={src} project={project} kind="mobile" sizes="260px" label={label} />
        <span className="absolute left-1/2 top-2 h-4 w-20 -translate-x-1/2 rounded-full bg-ink" aria-hidden="true" />
      </div>
    </div>
  );
}

function Block({ n, label, title, children, className = "" }) {
  return (
    <section className={`${wrap} py-16 sm:py-24 ${className}`} aria-label={label}>
      <Reveal y={16}>
        <p className="eyebrow mb-5 flex items-center gap-3">
          <span className="text-[color:var(--accent)]">{n}</span>
          <span className="h-px w-8 bg-white/25" aria-hidden="true" />
          {label}
        </p>
      </Reveal>
      {title && <SplitReveal as="h2" text={title} className="h-display mb-10 max-w-3xl text-[clamp(1.8rem,4.4vw,3.2rem)] text-white" />}
      {children}
    </section>
  );
}

function Meta({ project }) {
  const rows = [
    ["Client", project.name],
    ["Platform", project.platform],
    ["Type", project.type],
    ["Live site", project.host],
  ];
  return (
    <dl className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-4">
      {rows.map(([k, v]) => (
        <div key={k} className="border-t border-white/15 pt-3">
          <dt className="eyebrow">{k}</dt>
          <dd className="mt-1.5 text-sm text-white">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

/* ----------------------------- hero variants ----------------------------- */

function Hero({ project }) {
  const shot = project.shots.desktop[0];
  const title = (
    <SplitReveal
      gate
      as="h1"
      text={project.name}
      className={`h-display text-white ${project.variant === "editorial" ? "text-[clamp(2.8rem,10vw,8rem)]" : "text-[clamp(2.6rem,7.4vw,6rem)]"}`}
    />
  );
  const lede = (
    <Reveal gate delay={0.4} className="mt-6 max-w-xl text-base leading-relaxed text-silver/85 sm:text-lg">
      <p>{project.short}</p>
    </Reveal>
  );
  const cta = (
    <Reveal gate delay={0.55} className="mt-8 flex flex-wrap gap-3" y={20}>
      <a href={project.url} target="_blank" rel="noopener noreferrer" className="btn btn-primary" data-cursor="Visit">
        Visit Live Website <ArrowUpRight size={16} aria-hidden="true" />
      </a>
      <a href="#introduction" className="btn btn-ghost">
        Read the case study
      </a>
    </Reveal>
  );
  const crumb = (
    <Reveal gate y={12}>
      <Link href="/work" className="eyebrow mb-6 inline-flex min-h-[44px] items-center gap-2 transition hover:text-white">
        <span aria-hidden="true">&larr;</span> All work <span className="text-white/30">/</span> {project.number}
      </Link>
    </Reveal>
  );

  if (project.variant === "cinematic") {
    return (
      <section className="relative isolate flex min-h-[100svh] items-end overflow-hidden pb-16 pt-32">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 opacity-60">
            <ProjectShot src={shot} project={project} priority sizes="100vw" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-ink/10" />
        </div>
        <div className={`${wrap} w-full`}>
          {crumb}
          {title}
          {lede}
          {cta}
        </div>
      </section>
    );
  }

  if (project.variant === "editorial") {
    return (
      <section className="relative isolate overflow-hidden pb-10 pt-36 text-center">
        <div className="absolute inset-x-0 top-0 -z-10 h-[70%]" style={{ background: `radial-gradient(60% 60% at 50% 0%, ${project.accent}1f, transparent 70%)` }} />
        <div className={wrap}>
          <div className="flex justify-center">{crumb}</div>
          {title}
          <div className="mx-auto flex max-w-xl flex-col items-center">
            {lede}
            {cta}
          </div>
          <div className="mx-auto mt-14 max-w-5xl">
            <Browser project={project} src={shot} priority label="homepage" />
          </div>
        </div>
      </section>
    );
  }

  if (project.variant === "blueprint") {
    return (
      <section className="relative isolate flex min-h-[100svh] items-center overflow-hidden pb-16 pt-32">
        <div
          className="absolute inset-0 -z-10 opacity-[0.14]"
          style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.5) 1px, transparent 1px)",
            backgroundSize: "56px 56px",
            maskImage: "radial-gradient(70% 70% at 50% 40%, #000, transparent)",
            WebkitMaskImage: "radial-gradient(70% 70% at 50% 40%, #000, transparent)",
          }}
        />
        <div className={`${wrap} grid w-full items-center gap-12 lg:grid-cols-[1fr_1.1fr]`}>
          <div>
            {crumb}
            <p className="mb-4 font-mono text-xs text-[color:var(--accent)]">&lt;/&gt; hand-coded &middot; html / css / js</p>
            {title}
            {lede}
            {cta}
          </div>
          <div className="relative">
            <span className="absolute -left-3 -top-3 h-6 w-6 border-l border-t border-[color:var(--accent)]" aria-hidden="true" />
            <span className="absolute -bottom-3 -right-3 h-6 w-6 border-b border-r border-[color:var(--accent)]" aria-hidden="true" />
            <Browser project={project} src={shot} priority label="homepage" sizes="(min-width:1024px) 600px, 100vw" />
          </div>
        </div>
      </section>
    );
  }

  // split (default)
  return (
    <section className="relative isolate flex min-h-[100svh] items-center overflow-hidden pb-16 pt-32">
      <div className="absolute inset-0 -z-10" style={{ background: `radial-gradient(50% 50% at 80% 40%, ${project.accent}24, transparent 70%)` }} />
      <div className={`${wrap} grid w-full items-center gap-12 lg:grid-cols-[1fr_1.15fr]`}>
        <div>
          {crumb}
          {title}
          {lede}
          {cta}
        </div>
        <div style={{ perspective: 1400 }}>
          <div className="transition-transform duration-700 lg:[transform:rotateY(-9deg)_rotateX(3deg)] lg:hover:[transform:rotateY(-3deg)]">
            <Browser project={project} src={shot} priority label="homepage" sizes="(min-width:1024px) 640px, 100vw" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- page ----------------------------- */

export default function CaseStudy({ project, next }) {
  const { variant } = project;
  const listStyle = variant === "editorial" || variant === "blueprint";

  return (
    <article style={{ "--accent": project.accent }}>
      <Hero project={project} />

      {/* 2. large screenshot */}
      <section className={`${wrap} py-10 sm:py-16`} aria-label="Website overview">
        <ImageReveal>
          <Parallax speed={0} className="">
            <Browser project={project} src={project.shots.desktop[0]} aspect="aspect-[16/10] sm:aspect-[16/9]" label="full width" />
          </Parallax>
        </ImageReveal>
      </section>

      {/* 3. introduction */}
      <section id="introduction" className={`${wrap} py-16 sm:py-24`} aria-label="Project introduction">
        <Reveal y={16}>
          <p className="eyebrow mb-5 flex items-center gap-3">
            <span className="text-[color:var(--accent)]">01</span>
            <span className="h-px w-8 bg-white/25" aria-hidden="true" />
            Introduction
          </p>
        </Reveal>
        <Reveal className="mb-14 max-w-4xl">
          <p className="font-display text-[clamp(1.5rem,3.6vw,2.6rem)] font-semibold leading-snug tracking-tight text-white">{project.intro}</p>
        </Reveal>
        <Reveal>
          <Meta project={project} />
        </Reveal>
      </section>

      {/* 4. about the brand */}
      <Block n="02" label="About the brand">
        <div className="grid gap-10 lg:grid-cols-[1fr_1fr]">
          <Reveal>
            <p className="max-w-xl text-base leading-relaxed text-silver/85 sm:text-lg">{project.about}</p>
          </Reveal>
          <Reveal delay={0.1}>
            <a
              href={project.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group panel flex items-center justify-between gap-4 rounded-2xl p-5 transition hover:border-white/30"
            >
              <span>
                <span className="eyebrow block">Live website</span>
                <span className="mt-1 block text-lg text-white">{project.host}</span>
              </span>
              <ArrowUpRight className="text-mist transition group-hover:text-white" aria-hidden="true" />
            </a>
          </Reveal>
        </div>
      </Block>

      {/* 5. objectives */}
      <Block n="03" label="Project objectives" title="What the project set out to do.">
        <Reveal stagger={0.1} className={listStyle ? "divide-y divide-white/10 border-y border-white/10" : "grid gap-4 md:grid-cols-3"}>
          {project.objectives.map((o, i) =>
            listStyle ? (
              <div key={o} className="flex items-baseline gap-6 py-6">
                <span className="font-display text-4xl font-bold text-[color:var(--accent)]/80">0{i + 1}</span>
                <p className="text-lg text-white">{o}</p>
              </div>
            ) : (
              <div key={o} className="panel rounded-3xl p-7">
                <span className="font-mono text-xs text-[color:var(--accent)]">0{i + 1}</span>
                <p className="mt-6 text-lg leading-snug text-white">{o}</p>
              </div>
            )
          )}
        </Reveal>
      </Block>

      {/* 6. development approach */}
      <Block n="04" label="Development approach" title="How it was built.">
        <Reveal stagger={0.12} className="relative grid gap-5 md:grid-cols-3">
          {project.approach.map((a, i) => (
            <div key={a} className="relative border-t border-white/20 pt-6">
              <span className="absolute -top-[5px] left-0 h-2.5 w-2.5 rounded-full bg-[color:var(--accent)]" aria-hidden="true" />
              <p className="font-mono text-xs text-mist">Step 0{i + 1}</p>
              <p className="mt-3 text-base leading-relaxed text-silver">{a}</p>
            </div>
          ))}
        </Reveal>
      </Block>

      {/* 7. design & visual direction */}
      <Block n="05" label="Design & visual direction">
        <Reveal className="relative max-w-4xl border-l-2 border-[color:var(--accent)] pl-6 sm:pl-10">
          <p className="font-display text-[clamp(1.4rem,3vw,2.2rem)] font-medium leading-snug text-white">{project.design}</p>
        </Reveal>
      </Block>

      {/* 8. technologies */}
      <Block n="06" label="Technologies used">
        <Reveal stagger={0.08} className="flex flex-wrap gap-3" y={20}>
          {project.tech.map((t) => (
            <span key={t} className="glass rounded-full px-6 py-3 font-display text-lg font-semibold text-white">
              {t}
            </span>
          ))}
        </Reveal>
        {project.slug === "think-build-creation" && (
          <p className="mt-5 text-xs text-mist">Technology stack as supplied by the project owner.</p>
        )}
      </Block>

      {/* 9. features */}
      <Block n="07" label="Important website features" title="What visitors get.">
        <Reveal stagger={0.09} className={listStyle ? "grid gap-x-10 md:grid-cols-2" : "grid gap-4 sm:grid-cols-2"}>
          {project.features.map((f) =>
            listStyle ? (
              <div key={f} className="flex items-start gap-4 border-b border-white/10 py-5">
                <Check size={18} className="mt-0.5 shrink-0 text-[color:var(--accent)]" aria-hidden="true" />
                <p className="text-white">{f}</p>
              </div>
            ) : (
              <div key={f} className="panel flex items-start gap-4 rounded-2xl p-6">
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/10 text-[color:var(--accent)]">
                  <Check size={16} aria-hidden="true" />
                </span>
                <p className="text-white">{f}</p>
              </div>
            )
          )}
        </Reveal>
      </Block>

      {/* 10. full-width screenshots */}
      <section className={`${wrap} space-y-8 py-16 sm:py-24`} aria-label="Desktop screenshots">
        {[1, 2].map((i) => (
          <ImageReveal key={i}>
            <Browser project={project} src={project.shots.desktop[i]} aspect="aspect-[16/10] sm:aspect-[16/9]" label={`section ${i + 1}`} />
          </ImageReveal>
        ))}
      </section>

      {/* 11. mobile */}
      <section className="overflow-hidden py-16 sm:py-24" aria-label="Mobile screenshots">
        <div className={wrap}>
          <Reveal y={16}>
            <p className="eyebrow mb-10 flex items-center gap-3">
              <span className="text-[color:var(--accent)]">08</span>
              <span className="h-px w-8 bg-white/25" aria-hidden="true" />
              On mobile
            </p>
          </Reveal>
          <Reveal stagger={0.14} className="flex snap-x snap-mandatory gap-6 overflow-x-auto pb-4 md:grid md:grid-cols-3 md:overflow-visible" y={50}>
            {project.shots.mobile.map((src, i) => (
              <div key={i} className={`snap-center ${i === 1 ? "md:mt-12" : ""}`}>
                <Phone project={project} src={src} label={`screen ${i + 1}`} />
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* 12. overview + 13. visit */}
      <Block n="09" label="Final overview">
        <Reveal className="max-w-3xl">
          <p className="font-display text-[clamp(1.4rem,3vw,2.2rem)] font-medium leading-snug text-white">{project.overview}</p>
        </Reveal>
        <Reveal delay={0.1} className="mt-10">
          <a href={project.url} target="_blank" rel="noopener noreferrer" className="btn btn-primary !px-9 !py-5 text-base" data-cursor="Visit">
            Visit Live Website <ArrowUpRight size={18} aria-hidden="true" />
          </a>
        </Reveal>
      </Block>

      {/* 14. next project */}
      <section className={`${wrap} pb-8 pt-8`} aria-label="Next project">
        <Link
          href={`/work/${next.slug}`}
          data-cursor="Next"
          className="group relative block overflow-hidden rounded-[2rem] border border-white/12 bg-coal p-8 transition hover:border-white/30 sm:p-14"
        >
          <div className="absolute inset-y-0 right-0 hidden w-1/2 opacity-40 transition-opacity duration-500 group-hover:opacity-70 md:block">
            <ProjectShot src={next.shots.desktop[0]} project={next} sizes="50vw" />
            <div className="absolute inset-0 bg-gradient-to-r from-coal via-coal/60 to-transparent" />
          </div>
          <div className="relative">
            <p className="eyebrow">Next project &middot; {next.number}</p>
            <p className="h-display mt-5 max-w-xl text-[clamp(2rem,5.5vw,4rem)] text-white">{next.name}</p>
            <span className="mt-8 inline-flex items-center gap-2 text-sm text-silver transition group-hover:text-white">
              View case study <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </span>
          </div>
        </Link>
      </section>
    </article>
  );
}
