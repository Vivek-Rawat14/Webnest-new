"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import ErrorBoundary from "./ErrorBoundary";
import { canUse3D, isLiteDevice } from "@/lib/webgl";

const BackdropScene = dynamic(() => import("./BackdropScene"), { ssr: false });

/** Fixed, pointer-transparent 3D layer behind the whole site. */
export default function SceneBackdrop() {
  const [on, setOn] = useState(false);
  const [lite, setLite] = useState(true);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    setOn(canUse3D());
    setLite(isLiteDevice());
    const vis = () => setVisible(!document.hidden);
    document.addEventListener("visibilitychange", vis);
    return () => document.removeEventListener("visibilitychange", vis);
  }, []);

  if (!on) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-0" aria-hidden="true">
      <ErrorBoundary fallback={null}>
        <BackdropScene lite={lite} active={visible} onDegrade={() => setOn(false)} />
      </ErrorBoundary>
    </div>
  );
}
