"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import ProjectCard from "./ProjectCard";
import { Reveal } from "./Reveal";

export default function ProjectsGrid({ projects }) {
  return (
    <Reveal stagger={0.12} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {projects.map((p, i) => (
        <ProjectCard key={p.slug} project={p} priority={i < 2} />
      ))}
      <Link
        href="/contact"
        data-cursor="Talk"
        className="group relative flex min-h-[260px] flex-col justify-between overflow-hidden rounded-3xl border border-dashed border-white/20 p-8 transition hover:border-white/50 sm:col-span-2 lg:col-span-2"
      >
        <span className="eyebrow">Next up</span>
        <div>
          <p className="h-display text-3xl text-white sm:text-4xl">Your project could be next.</p>
          <span className="mt-5 inline-flex items-center gap-2 text-sm text-silver transition group-hover:text-white">
            Start a conversation <ArrowUpRight size={16} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
          </span>
        </div>
        <div className="pointer-events-none absolute -right-10 -top-10 h-56 w-56 rounded-full bg-volt/20 blur-3xl transition group-hover:bg-volt/30" aria-hidden="true" />
      </Link>
    </Reveal>
  );
}
