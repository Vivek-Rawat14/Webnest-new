"use client";

import dynamic from "next/dynamic";
import Intro from "./Intro";
import Navbar from "./Navbar";
import Footer from "./Footer";
import CustomCursor from "./CustomCursor";
import MusicPlayer from "./MusicPlayer";
import SceneBackdrop from "./SceneBackdrop";

// The assistant (and its 3D robot) loads after the page is interactive.
const ChatAssistant = dynamic(() => import("./ChatAssistant"), { ssr: false });

export default function Shell({ children }) {
  return (
    <>
      <a
        href="#main"
        className="sr-only z-[110] rounded-full bg-white px-5 py-3 text-sm font-semibold text-ink focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>
      <Intro />
      <SceneBackdrop />
      <Navbar />
      <main id="main" tabIndex={-1} className="relative z-10 outline-none">
        {children}
      </main>
      <div className="relative z-10">
        <Footer />
      </div>
      <MusicPlayer />
      <ChatAssistant />
      <CustomCursor />
    </>
  );
}
