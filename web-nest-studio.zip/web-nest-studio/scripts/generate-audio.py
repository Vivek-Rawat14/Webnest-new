#!/usr/bin/env python3
"""
Generates the original audio for Web Nest Studio (no samples, no third-party material):
  public/audio/ambient.mp3  - seamless cinematic ambient loop
  public/audio/intro.mp3    - short cinematic logo sting for the intro
Requires: numpy, scipy, ffmpeg.   Run: python3 scripts/generate-audio.py
"""
import os, subprocess, tempfile
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile

SR = 32000
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), "..", "public", "audio")
os.makedirs(OUT, exist_ok=True)


def lp(x, fc, order=2):
    return sosfilt(butter(order, fc, btype="low", fs=SR, output="sos"), x)


def hp(x, fc, order=2):
    return sosfilt(butter(order, fc, btype="high", fs=SR, output="sos"), x)


def bp(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], btype="band", fs=SR, output="sos"), x)


def t_axis(sec):
    return np.arange(int(sec * SR)) / SR


def pad(freq, t, detune=0.0035, lfo_rate=0.07, phase=0.0):
    """Warm detuned saw-ish pad with a slow filter-like amplitude swell."""
    sig = np.zeros_like(t)
    for d in (-detune, 0, detune):
        f = freq * (1 + d)
        for h, a in ((1, 1.0), (2, 0.45), (3, 0.25), (4, 0.12)):
            sig += a * np.sin(2 * np.pi * f * h * t + phase + d * 40)
    swell = 0.6 + 0.4 * np.sin(2 * np.pi * lfo_rate * t + phase)
    return sig * swell


def pluck(freq, length=2.6):
    t = t_axis(length)
    env = np.exp(-t * 2.2) * (1 - np.exp(-t * 90))
    s = np.sin(2 * np.pi * freq * t) + 0.35 * np.sin(2 * np.pi * freq * 2.005 * t)
    return s * env


def stereo_delay(sig, time_l, time_r, fb=0.38, mix=0.5):
    n = len(sig)
    L = sig.copy()
    R = sig.copy()
    for ch, tm in ((L, time_l), (R, time_r)):
        d = int(tm * SR)
        buf = np.zeros(n)
        buf[d:] = sig[:-d]
        tap = buf
        for _ in range(4):
            nxt = np.zeros(n)
            nxt[d:] = tap[:-d] * fb
            buf += nxt
            tap = nxt
        ch += mix * lp(buf, 4200)
    return L, R


def reverb(sig, decay=2.6, mix=0.35):
    n = int(decay * SR)
    ir = rng.standard_normal(n) * np.exp(-np.linspace(0, 7, n))
    ir = lp(ir, 5000)
    ir /= np.max(np.abs(ir)) * 8
    from scipy.signal import fftconvolve
    wet = fftconvolve(sig, ir)[: len(sig)]
    return sig * (1 - mix) + wet * mix


def normalise(x, peak=0.8):
    return x / (np.max(np.abs(x)) + 1e-9) * peak


def seamless(x, xfade_sec):
    """Circular crossfade so the loop point is inaudible."""
    c = int(xfade_sec * SR)
    body = x[:-c].copy()
    fade = np.linspace(0, 1, c)
    body[:c] = body[:c] * fade + x[-c:] * (1 - fade)
    return body


def to_mp3(stereo, name, quality=5):
    wav = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    wavfile.write(wav.name, SR, (np.clip(stereo, -1, 1) * 32767).astype(np.int16))
    out = os.path.join(OUT, name)
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", wav.name, "-codec:a", "libmp3lame", "-q:a", str(quality), out],
        check=True,
    )
    os.unlink(wav.name)
    print("wrote", out, os.path.getsize(out) // 1024, "KB")


# ---------------------------------------------------------------- ambient loop
def ambient():
    loop = 40.0
    xf = 4.0
    t = t_axis(loop + xf)
    # Am(add9) -> Fmaj7 -> Cmaj9 -> Gsus2  (slow, 4 chords over the loop)
    chords = [
        [110.00, 164.81, 246.94, 329.63, 493.88],   # Am9-ish
        [87.31, 174.61, 261.63, 329.63, 440.00],    # Fmaj7
        [130.81, 196.00, 293.66, 329.63, 493.88],   # Cmaj9
        [98.00, 146.83, 196.00, 293.66, 392.00],    # Gsus2
    ]
    seg = len(t) // 4
    bed = np.zeros_like(t)
    for i, ch in enumerate(chords):
        a, b = i * seg, (i + 1) * seg if i < 3 else len(t)
        tt = t[a:b]
        s = sum(pad(f, tt, lfo_rate=0.05 + 0.01 * k, phase=k * 1.3) for k, f in enumerate(ch))
        # smooth chord crossfade
        n = len(tt)
        w = np.minimum(1, np.minimum(np.arange(n), n - np.arange(n)) / (3.5 * SR))
        bed[a:b] += s * w
    bed = lp(bed, 1400)
    # sub bass drone
    sub = np.sin(2 * np.pi * 55.0 * t) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.025 * t))
    bed += 0.9 * lp(sub, 120)

    # soft pulse (very quiet electronic heartbeat) every 2.5s
    pulse = np.zeros_like(t)
    step = int(2.5 * SR)
    pt = t_axis(0.5)
    kick = np.sin(2 * np.pi * (48 + 40 * np.exp(-pt * 22)) * pt) * np.exp(-pt * 9)
    for i in range(0, len(t) - len(kick), step):
        pulse[i : i + len(kick)] += kick * 0.22
    pulse = lp(pulse, 220)

    # sparse high plucks in A minor pentatonic
    notes = [440.0, 523.25, 587.33, 659.25, 783.99, 880.0, 987.77]
    plucks = np.zeros_like(t)
    pos = 3.0
    while pos < loop + xf - 3:
        f = notes[rng.integers(0, len(notes))]
        p = pluck(f) * rng.uniform(0.35, 0.8)
        i = int(pos * SR)
        j = min(len(plucks), i + len(p))
        plucks[i:j] += p[: j - i]
        pos += rng.choice([3.5, 5.0, 7.5, 5.0])
    pl_l, pl_r = stereo_delay(plucks, 0.43, 0.61, fb=0.45, mix=0.9)

    # airy noise texture
    air = bp(rng.standard_normal(len(t)), 3000, 9000)
    air *= 0.5 + 0.5 * np.sin(2 * np.pi * 0.06 * t)
    air *= 0.03

    bed_n = normalise(bed, 0.55)
    left = bed_n + 0.55 * normalise(pl_l, 0.35) + air + pulse
    right = bed_n * 0.97 + 0.55 * normalise(pl_r, 0.35) + np.roll(air, 900) + pulse
    left, right = reverb(left, 3.2, 0.4), reverb(right, 3.6, 0.4)
    st = np.stack([seamless(left, xf), seamless(right, xf)], axis=1)
    st = normalise(st, 0.7)
    to_mp3(st, "ambient.mp3", quality=6)


# ---------------------------------------------------------------- intro sting
def intro():
    dur = 5.2
    t = t_axis(dur)
    # riser: filtered noise sweeping up
    n = rng.standard_normal(len(t))
    # band-limited noise with a rising gain curve
    band = bp(n, 800, 7000)
    riser = band * (np.clip(t / 2.6, 0, 1) ** 3) * np.exp(-np.clip(t - 2.6, 0, None) * 5)
    # boom at the logo hit (2.6s)
    hit = 2.6
    ht = t_axis(dur)
    local = np.clip(ht - hit, 0, None)
    boom = np.sin(2 * np.pi * (42 + 70 * np.exp(-local * 6)) * local) * np.exp(-local * 1.6) * (ht >= hit)
    # shimmering chord after the hit
    chord = sum(
        np.sin(2 * np.pi * f * ht) * (ht >= hit) * np.exp(-local * 0.9) * (1 - np.exp(-local * 40))
        for f in (220.0, 329.63, 440.0, 659.25, 880.0)
    ) * 0.22
    shimmer = hp(rng.standard_normal(len(t)), 6000) * (ht >= hit) * np.exp(-local * 3.0) * 0.12
    mono = normalise(riser * 0.9, 0.5) + normalise(boom, 0.9) * 0.9 + chord + shimmer
    l, r = stereo_delay(mono, 0.19, 0.27, fb=0.35, mix=0.5)
    l, r = reverb(l, 2.4, 0.35), reverb(r, 2.6, 0.35)
    st = np.stack([l, r], axis=1)
    fade = np.minimum(1, (dur - t) / 0.8)
    st = normalise(st * fade[:, None], 0.8)
    to_mp3(st, "intro.mp3", quality=5)


if __name__ == "__main__":
    ambient()
    intro()
