#!/usr/bin/env node
/**
 * Captures real screenshots of the four live websites into public/projects/<slug>/.
 *
 *   npm i -D playwright && npx playwright install chromium
 *   npm run screenshots
 *
 * Output per project: desktop-1..3.jpg (1440px wide, three scroll positions) and
 * mobile-1..3.jpg (390px wide @2x). The site picks them up automatically on the next build/dev reload.
 */
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

let chromium;
try {
  ({ chromium } = await import("playwright"));
} catch {
  console.error("Playwright is not installed. Run: npm i -D playwright && npx playwright install chromium");
  process.exit(1);
}

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "projects");
const sites = [
  { slug: "house-of-taarini", url: "https://taarinihouse.com/" },
  { slug: "mystic-weaves", url: "https://mysticweaves.in/" },
  { slug: "white-lotus", url: "https://www.thewhitelotussarees.com/" },
  { slug: "think-build-creation", url: "https://thinkbuildcreation.com/" },
];

const dismissOverlays = async (page) => {
  // Best-effort: close cookie banners / newsletter popups so the screenshots show the real site.
  for (const sel of ['button:has-text("Accept")', 'button:has-text("Close")', '[aria-label="Close"]', 'button:has-text("No thanks")']) {
    try {
      await page.locator(sel).first().click({ timeout: 800 });
    } catch {}
  }
};

const shoot = async (browser, site, kind, ctxOpts, vh) => {
  const ctx = await browser.newContext(ctxOpts);
  const page = await ctx.newPage();
  await page.goto(site.url, { waitUntil: "networkidle", timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(2500);
  await dismissOverlays(page);
  for (let i = 0; i < 3; i++) {
    await page.evaluate((y) => window.scrollTo({ top: y, behavior: "instant" }), i * vh);
    await page.waitForTimeout(1200); // let lazy images and reveal animations settle
    const file = path.join(root, site.slug, `${kind}-${i + 1}.jpg`);
    await page.screenshot({ path: file, type: "jpeg", quality: 86 });
    console.log("saved", path.relative(process.cwd(), file));
  }
  await ctx.close();
};

const browser = await chromium.launch();
let failed = 0;
for (const site of sites) {
  await mkdir(path.join(root, site.slug), { recursive: true });
  try {
    await shoot(browser, site, "desktop", { viewport: { width: 1440, height: 900 } }, 900);
    await shoot(
      browser,
      site,
      "mobile",
      { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
      844
    );
  } catch (e) {
    failed++;
    console.error(`FAILED ${site.url}: ${e.message}`);
  }
}
await browser.close();
process.exit(failed ? 1 : 0);
