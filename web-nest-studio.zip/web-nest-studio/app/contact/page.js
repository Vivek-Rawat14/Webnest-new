import Contact from "@/components/Contact";

export const metadata = {
  title: "Contact",
  description: "Have a project in mind? Get in touch with Web Nest Studio.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <section aria-label="Contact" className="mx-auto max-w-6xl px-5 pb-12 pt-36 sm:px-8 sm:pt-44">
      <Contact heading="h1" />
    </section>
  );
}
