import PageHeader from "@/components/PageHeader";
import Services from "@/components/Services";

export const metadata = {
  title: "Services",
  description: "Shopify development, WordPress, Android apps, website design, redesign and ongoing maintenance.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  return (
    <>
      <PageHeader eyebrow="Services" title="What I can build for you." text="Eight ways to work together, from a single storefront to an ongoing retainer." />
      <section aria-label="Services" className="mx-auto max-w-6xl px-5 pb-12 sm:px-8">
        <Services />
      </section>
    </>
  );
}
