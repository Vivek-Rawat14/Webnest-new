import About from "@/components/About";

export const metadata = {
  title: "About",
  description: "A freelance web developer focused on Shopify, full-stack development, WordPress, apps and creative web experiences.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <section aria-label="About" className="mx-auto max-w-6xl px-5 pb-12 pt-36 sm:px-8 sm:pt-44">
      <About heading="h1" />
    </section>
  );
}
