import { ImageResponse } from "next/og";

export const alt = "Web Nest Studio - Crafting Digital Experiences Beyond Imagination.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "radial-gradient(circle at 50% 38%, #1c1c24 0%, #050506 62%)",
          color: "#fff",
          fontFamily: "sans-serif",
        }}
      >
        <svg width="190" height="190" viewBox="0 0 64 64" fill="none">
          <defs>
            <linearGradient id="g" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="#ffffff" />
              <stop offset=".5" stopColor="#bfc3cc" />
              <stop offset="1" stopColor="#7d818c" />
            </linearGradient>
          </defs>
          <g stroke="url(#g)" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 10 L19 54 L32 24 L45 54 L59 10" strokeWidth="3.2" />
            <path d="M14 20 L24 50 L32 34 L40 50 L50 20" strokeWidth="2.6" opacity=".8" />
            <path d="M23 29 L28 46 L32 40 L36 46 L41 29" strokeWidth="2" opacity=".65" />
          </g>
          <circle cx="32" cy="12" r="2.8" fill="url(#g)" />
        </svg>
        <div style={{ marginTop: 28, fontSize: 68, fontWeight: 800, letterSpacing: 18 }}>WEB NEST</div>
        <div style={{ marginTop: 6, fontSize: 24, letterSpacing: 24, color: "#8b8f99" }}>STUDIO</div>
        <div style={{ marginTop: 42, fontSize: 30, color: "#c9ccd3" }}>
          Crafting Digital Experiences Beyond Imagination.
        </div>
      </div>
    ),
    { ...size }
  );
}
