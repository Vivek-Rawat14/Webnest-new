import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import SectionHead from "@/components/SectionHead";
import ProjectsGrid from "@/components/ProjectsGrid";
import Services from "@/components/Services";
import About from "@/components/About";
import Skills from "@/components/Skills";
import Contact from "@/components/Contact";
import { projectsWithShots } from "@/lib/shots";

export const metadata = {
  alternates: { canonical: "/" },
};

const wrap = "mx-auto max-w-6xl px-5 py-24 sm:px-8 sm:py-32";

export default function HomePage() {
  const projects = projectsWithShots();
  return (
    <>
      <Hero />
      <Marquee />

      <section id="work" aria-labelledby="work-title" className={wrap}>
        <SectionHead eyebrow="Selected Work" title="Four live projects. Real stores, real websites." text="Each one is live on the web today. Open a case study to see how it was approached." />
        <h2 id="work-title" className="sr-only">Selected work</h2>
        <ProjectsGrid projects={projects} />
        <div className="mt-10 text-center">
          <Link href="/work" className="btn btn-ghost">
            View all work <ArrowRight size={16} aria-hidden="true" />
          </Link>
        </div>
      </section>

      <section id="about" aria-label="About" className={wrap}>
        <About />
      </section>

      <section id="services" aria-labelledby="services-title" className={wrap}>
        <SectionHead eyebrow="Services" title="What I can build for you." text="From Shopify storefronts to custom apps, with design and long-term care built in." />
        <h2 id="services-title" className="sr-only">Services</h2>
        <Services />
        <div className="mt-10 text-center">
          <Link href="/services" className="btn btn-ghost">
            All services <ArrowRight size={16} aria-hidden="true" />
          </Link>
        </div>
      </section>

      <section id="skills" aria-labelledby="skills-title" className={wrap}>
        <SectionHead eyebrow="Skills & Technologies" title="The toolkit behind the work." />
        <h2 id="skills-title" className="sr-only">Skills and technologies</h2>
        <Skills />
      </section>

      <section id="contact" aria-label="Contact" className={wrap}>
        <Contact />
      </section>
    </>
  );
}
