import "@fontsource-variable/syne";
import "@fontsource-variable/inter";
import "@fontsource-variable/jetbrains-mono";
import "./globals.css";
import Shell from "@/components/Shell";
import { site } from "@/lib/site";

export const metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} | Shopify, Full-Stack & Creative Web Development`, template: `%s | ${site.name}` },
  description: site.description,
  applicationName: site.name,
  keywords: ["freelance web developer", "Shopify developer", "full stack developer", "WordPress developer", "Android app development", "website redesign"],
  openGraph: {
    type: "website",
    siteName: site.name,
    title: `${site.name} | ${site.tagline}`,
    description: site.description,
    url: "/",
  },
  twitter: { card: "summary_large_image", title: site.name, description: site.tagline },
  robots: { index: true, follow: true },
};

export const viewport = {
  themeColor: "#050506",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

// Runs before first paint: marks JS-enabled (enables reveal animations) and hides the intro overlay if already seen.
const bootScript = `(function(){var d=document.documentElement;d.classList.add('js');try{if(sessionStorage.getItem('wns-intro-seen')==='1')d.classList.add('intro-seen');}catch(e){}})();`;

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: bootScript }} />
        <style>{`.intro-seen .intro-root{display:none!important}`}</style>
      </head>
      <body className="grain font-sans">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
