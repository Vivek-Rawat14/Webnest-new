import Link from "next/link";
import { LogoMark } from "@/components/Logo";

export const metadata = { title: "Page not found" };

export default function NotFound() {
  return (
    <section className="mx-auto grid min-h-[80vh] max-w-xl place-items-center px-6 text-center">
      <div className="flex flex-col items-center">
        <LogoMark size={72} />
        <p className="eyebrow mb-4 mt-8">Error 404</p>
        <h1 className="h-display text-5xl text-white">Lost in the nest.</h1>
        <p className="mt-4 text-mist">That page doesn&apos;t exist, but plenty of good work does.</p>
        <Link href="/work" className="btn btn-primary mt-8">
          See the work
        </Link>
      </div>
    </section>
  );
}
