import { NextResponse } from "next/server";

export const runtime = "nodejs";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const hits = new Map(); // naive in-memory rate limit (per server instance)

function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  list.push(now);
  hits.set(ip, list);
  return list.length > 5;
}

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export async function POST(req) {
  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "bad_request", message: "Invalid request." }, { status: 400 });
  }

  // Honeypot: pretend success so bots move on.
  if (body.website) return NextResponse.json({ ok: true });

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (limited(ip)) {
    return NextResponse.json({ error: "rate_limited", message: "Too many messages. Please try again later." }, { status: 429 });
  }

  const v = {
    name: String(body.name || "").trim(),
    email: String(body.email || "").trim(),
    typeLabel: String(body.typeLabel || body.type || "").trim(),
    budget: String(body.budget || "").trim(),
    message: String(body.message || "").trim(),
  };
  const fields = {};
  if (v.name.length < 2 || v.name.length > 120) fields.name = "Please enter your name.";
  if (!EMAIL_RE.test(v.email) || v.email.length > 200) fields.email = "Please enter a valid email address.";
  if (!v.typeLabel) fields.type = "Please choose a project type.";
  if (v.message.length < 10 || v.message.length > 3000) fields.message = "Message must be 10-3000 characters.";
  if (v.budget.length > 80) fields.budget = "Keep the budget note under 80 characters.";
  if (Object.keys(fields).length) {
    return NextResponse.json({ error: "invalid", message: "Please check the highlighted fields.", fields }, { status: 400 });
  }

  const key = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL;
  if (!key || !to) {
    // Honest fallback: delivery is not configured, so the client opens a mailto: link instead.
    return NextResponse.json({ error: "not_configured" }, { status: 503 });
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.CONTACT_FROM_EMAIL || "Web Nest Studio <onboarding@resend.dev>",
        to: [to],
        reply_to: v.email,
        subject: `New enquiry: ${v.typeLabel} - ${v.name}`,
        html: `<h2>New project enquiry</h2>
<p><b>Name:</b> ${esc(v.name)}<br><b>Email:</b> ${esc(v.email)}<br><b>Project type:</b> ${esc(v.typeLabel)}<br><b>Budget:</b> ${esc(v.budget || "-")}</p>
<p style="white-space:pre-wrap">${esc(v.message)}</p>`,
      }),
    });
    if (!res.ok) throw new Error(`mail provider ${res.status}`);
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "send_failed", message: "The message could not be sent. Please try again or email directly." }, { status: 502 });
  }
}
