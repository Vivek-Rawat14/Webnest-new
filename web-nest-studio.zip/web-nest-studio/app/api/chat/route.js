import { NextResponse } from "next/server";
import { localAnswer, systemPrompt } from "@/lib/knowledge";

export const runtime = "nodejs";

const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60 * 1000);
  list.push(now);
  hits.set(ip, list);
  return list.length > 20;
}

const clean = (s) => String(s || "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, 500);

async function askModel(messages) {
  const key = process.env.ANTHROPIC_API_KEY; // server-side only, never sent to the browser
  if (!key) return null;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 400,
      system: systemPrompt(),
      messages,
    }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`model ${res.status}`);
  const data = await res.json();
  const text = data?.content?.find((b) => b.type === "text")?.text?.trim();
  return text || null;
}

export async function POST(req) {
  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "bad_request" }, { status: 400 });
  }
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (limited(ip)) return NextResponse.json({ error: "rate_limited", reply: "You're sending messages quickly - please wait a moment." }, { status: 429 });

  // Keep the last few turns, roles restricted, content bounded.
  const history = (Array.isArray(body.messages) ? body.messages : [])
    .filter((m) => (m.role === "user" || m.role === "assistant") && clean(m.content))
    .slice(-10)
    .map((m) => ({ role: m.role, content: clean(m.content) }));
  while (history.length && history[0].role !== "user") history.shift();
  const last = history[history.length - 1];
  if (!last || last.role !== "user") return NextResponse.json({ error: "empty" }, { status: 400 });

  // Local knowledge base gives us the links; the model (if configured) gives the wording.
  const local = localAnswer(last.content);

  try {
    const text = await askModel(history);
    if (text) return NextResponse.json({ reply: text, links: local.links || [], mode: "ai" });
  } catch {
    // fall through to the local knowledge base
  }
  return NextResponse.json({ reply: local.reply, links: local.links || [], mode: "local" });
}
