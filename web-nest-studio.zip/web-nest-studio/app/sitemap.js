import { projects } from "@/lib/data";
import { site } from "@/lib/site";

export default function sitemap() {
  const pages = ["", "/work", "/about", "/services", "/skills", "/contact"].map((p) => ({
    url: `${site.url}${p}`,
    changeFrequency: "monthly",
    priority: p === "" ? 1 : 0.8,
  }));
  const work = projects.map((p) => ({ url: `${site.url}/work/${p.slug}`, changeFrequency: "monthly", priority: 0.7 }));
  return [...pages, ...work];
}
