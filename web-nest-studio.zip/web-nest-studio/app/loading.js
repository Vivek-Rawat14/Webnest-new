import { LogoMark } from "@/components/Logo";

export default function Loading() {
  return (
    <div className="grid min-h-[70vh] place-items-center" role="status" aria-live="polite">
      <div className="animate-pulse">
        <LogoMark size={64} />
      </div>
      <span className="sr-only">Loading</span>
    </div>
  );
}
