"use client";

import Link from "next/link";

export default function Error({ reset }) {
  return (
    <section className="mx-auto grid min-h-[70vh] max-w-xl place-items-center px-6 text-center">
      <div>
        <p className="eyebrow mb-4">Something went wrong</p>
        <h1 className="h-display text-4xl text-white">This page hit a snag.</h1>
        <p className="mt-4 text-mist">Please try again, or head back home.</p>
        <div className="mt-8 flex justify-center gap-3">
          <button type="button" onClick={reset} className="btn btn-primary">
            Try again
          </button>
          <Link href="/" className="btn btn-ghost">
            Home
          </Link>
        </div>
      </div>
    </section>
  );
}
