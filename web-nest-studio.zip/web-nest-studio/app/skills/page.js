import PageHeader from "@/components/PageHeader";
import Skills from "@/components/Skills";

export const metadata = {
  title: "Skills & Technologies",
  description: "HTML, CSS, JavaScript, React, Next.js, Shopify, Liquid, WordPress, Node.js, GSAP, Three.js, Tailwind CSS and app development.",
  alternates: { canonical: "/skills" },
};

export default function SkillsPage() {
  return (
    <>
      <PageHeader eyebrow="Skills & Technologies" title="The toolkit behind the work." text="Filter by area to see how the stack fits together." />
      <section aria-label="Technologies" className="mx-auto max-w-6xl px-5 pb-12 sm:px-8">
        <Skills />
      </section>
    </>
  );
}
