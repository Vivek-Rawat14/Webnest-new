import PageHeader from "@/components/PageHeader";
import ProjectsGrid from "@/components/ProjectsGrid";
import { projectsWithShots } from "@/lib/shots";

export const metadata = {
  title: "Work",
  description: "Live projects by Web Nest Studio: House of Taarini, Mystic Weaves, The White Lotus Sarees and Think Build Creation.",
  alternates: { canonical: "/work" },
};

export default function WorkPage() {
  return (
    <>
      <PageHeader
        eyebrow="Work"
        title="Selected projects, live on the web."
        text="Three Shopify stores and one custom-coded website. Open any project for its case study."
      />
      <section aria-label="Projects" className="mx-auto max-w-6xl px-5 pb-12 sm:px-8">
        <ProjectsGrid projects={projectsWithShots()} />
      </section>
    </>
  );
}
