import { notFound } from "next/navigation";
import CaseStudy from "@/components/CaseStudy";
import { projects, getProject, getNextProject } from "@/lib/data";
import { shotsFor } from "@/lib/shots";

export const dynamicParams = false;

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const p = getProject(slug);
  if (!p) return {};
  return {
    title: `${p.name} - Case Study`,
    description: p.short,
    alternates: { canonical: `/work/${p.slug}` },
    openGraph: { title: `${p.name} - Case Study | Web Nest Studio`, description: p.short, url: `/work/${p.slug}` },
  };
}

export default async function CaseStudyPage({ params }) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) notFound();
  const next = getNextProject(slug);
  return (
    <CaseStudy
      project={{ ...project, shots: shotsFor(project.slug) }}
      next={{ ...next, shots: shotsFor(next.slug) }}
    />
  );
}
