"use client";

import { motion } from "framer-motion";

// Re-mounts on every navigation: a soft rise-and-fade between pages.
export default function Template({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.65, ease: [0.2, 0.8, 0.2, 1] }}
    >
      {children}
    </motion.div>
  );
}
