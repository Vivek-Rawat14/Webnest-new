/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}", "./lib/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#050506",
        coal: "#0c0c0f",
        graphite: "#141418",
        steel: "#1d1d23",
        silver: "#c9ccd3",
        mist: "#8b8f99",
        volt: "#7c5cff",
        ice: "#5ce1ff",
      },
      fontFamily: {
        display: ["'Syne Variable'", "system-ui", "sans-serif"],
        sans: ["'Inter Variable'", "system-ui", "sans-serif"],
        mono: ["'JetBrains Mono Variable'", "ui-monospace", "monospace"],
      },
      keyframes: {
        sheen: {
          "0%": { backgroundPosition: "200% 0" },
          "100%": { backgroundPosition: "-200% 0" },
        },
        pulseDot: {
          "0%,100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: ".4", transform: "scale(.7)" },
        },
        eq: {
          "0%,100%": { transform: "scaleY(.25)" },
          "50%": { transform: "scaleY(1)" },
        },
      },
      animation: {
        sheen: "sheen 6s linear infinite",
        pulseDot: "pulseDot 1.8s ease-in-out infinite",
        eq: "eq 1s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
